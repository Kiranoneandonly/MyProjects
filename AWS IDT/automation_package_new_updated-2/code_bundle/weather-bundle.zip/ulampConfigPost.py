import json
import boto3
import json


def lambda_handler(event, context):
    # TODO implement
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('ulampconfig')
    
    print(event)
    print(context)
    response = table.update_item(
    Key={
        'id': "1"
    },
    UpdateExpression="set  sunrise = :r, sunset=:p , manual=:m",
    ExpressionAttributeValues={
        ':r': event["sunrise"],
        ':p': event["sunset"],
        ':m' : event["manual"]
    },
    ReturnValues="UPDATED_NEW"
    )
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('updated the schedule!')
    }
