from botocore.vendored import requests 
import json 
import sys
import time
import calendar
import boto3

def get_weather_data(url,longitude,latitude):
	#URL = "https://api.weather.gov/points/37.2567,-121.7862"
	URL = "https://api.weather.gov/points/"+longitude+","+latitude

	data = {}
	url_request = requests.get(url = URL) 
	url_data = url_request.json()
	#print(json.dumps(data,indent=4))
	forecast_url = url_data["properties"]["forecastHourly"]
	forecast_request =  requests.get(url = forecast_url)
	forecast_data = forecast_request.json()
	#print(json.dumps(forecast_data,indent=4))
	data["startTime"] = forecast_data["properties"]["periods"][0]["startTime"]
	data["endTime"] = forecast_data["properties"]["periods"][0]["endTime"]
	data["isDayTime"] = forecast_data["properties"]["periods"][0]["isDaytime"]
	data["forecast"] = forecast_data["properties"]["periods"][0]["shortForecast"]
	data["city"] = url_data["properties"]["relativeLocation"]["properties"]["city"]

	print(json.dumps(data,indent=4))

def get_weather_data_openweathermap(url="https://api.openweathermap.org/data/2.5/weather",longitude=37.2570438,latitude=-121.7863171,appid="e0f59d72ac1a12fdac6ce602d861a4ca"):

	#URL = "https://api.openweathermap.org/data/2.5/weather?lat="+"&lon="+"&appid="+"e0f59d72ac1a12fdac6ce602d861a4ca"
	URL = url+"?lat="+str(longitude)+"&lon="+str(latitude)+"&appid="+appid
	print(URL)
	data={}
	url_request = requests.get(url = URL) 
	url_data = url_request.json()
	print(url_data)
	print(json.dumps(url_data,indent=4))
	print(url_data["sys"]["sunrise"])
	print(url_data["sys"]["sunset"])
	print(calendar.timegm(time.gmtime()))

	if((calendar.timegm(time.gmtime()) > url_data["sys"]["sunrise"] ) and (calendar.timegm(time.gmtime()) < url_data["sys"]["sunset"] ) ):
		data["isDayTime"] = True
	else:
		data["isDayTime"] = False

	print(data)

	return data
	
	

def lambda_handler(event, context):
    # TODO implement
    print("cron debug weather")
    #weather_data = get_weather_data("test","41.446755" ,"-80.6709471")

    #penang
    weather_data = get_weather_data_openweathermap("https://api.openweathermap.org/data/2.5/weather",5.376580,100.3369139,"e0f59d72ac1a12fdac6ce602d861a4ca")
   
	#india
    #weather_data = get_weather_data_openweathermap("https://api.openweathermap.org/data/2.5/weather",17.4122998,78.2679591,"e0f59d72ac1a12fdac6ce602d861a4ca")
    
    #Berlin
    #weather_data = get_weather_data_openweathermap("https://api.openweathermap.org/data/2.5/weather",52.5065133,13.1445542,"e0f59d72ac1a12fdac6ce602d861a4ca")


    endpoints=["fe80::211:7d00:30:17b7","fe80::211:7d00:30:4a01","fe80:211:7d00:30:185f","fe80:211:7d00:30:1694"]


    print(weather_data)
    client = boto3.client('iot-data')




    switch_state = {"msgType":"switch","state":0,"address":"fe80::211:7d00:30:17b7"}
    
    if(weather_data["isDayTime"] == True):
        switch_state["state"] = 1
    else:
        switch_state["state"] = 0


    for addr in endpoints:
    	switch_state = {"msgType":"switch","state":0}
    	switch_state["address"] = addr
    	response = client.publish(
        topic='IDT-Test/Publish/Topic',
        qos=0,
        payload=json.dumps(switch_state)
    )


# penang co-ordinates
#get_weather_data_openweathermap("https://api.openweathermap.org/data/2.5/weather",5.376580,100.3369139,"e0f59d72ac1a12fdac6ce602d861a4ca")

#india co-ordinates 17.4122998,78.2679591
#get_weather_data_openweathermap("https://api.openweathermap.org/data/2.5/weather",17.4122998,78.2679591,"e0f59d72ac1a12fdac6ce602d861a4ca")

# berlin 52.5065133,13.1445542
#get_weather_data_openweathermap("https://api.openweathermap.org/data/2.5/weather",52.5065133,13.1445542,"e0f59d72ac1a12fdac6ce602d861a4ca")



#get_weather_data("test",longitude,latitude)