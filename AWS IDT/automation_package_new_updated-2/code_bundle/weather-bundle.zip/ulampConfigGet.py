import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    print(event)
    print(context)
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table('ulampconfig')
    response = table.get_item(
        Key={
            'id': "1"
        }
    )
    print(response["Item"])

    return {
        'statusCode': 200,
        'body': (response["Item"])
    }
