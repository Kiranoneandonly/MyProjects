import json
import datetime
import boto3

DIM_TABLE = "DimHistory"
LCM_Status = "LCMStatus"

dynamodb = boto3.client('dynamodb')

def parse_IoT_Lamp_response(event, context):
    """process the data related to lamp and store it in the database.
    
    Parameters
    ----------
    event : dict
        data pertaining MQTT message

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html
    """
    print(event)

    event["timestamp"] = float(event["timestamp"])/1000
    dt = datetime.datetime.fromtimestamp(event["timestamp"])
            
    event["date"] = {
        "year": dt.year,
        "month": dt.month,
        "day": dt.day,
        "weekday": dt.isoweekday(),
        "hour": dt.hour,
        "minute": dt.minute,
        "second": dt.second
    }

    item = prepare_dict_data(event)
    print("prepared for db: ",item)

    if "action" in event:
        if event["action"] == "dim":
            item.pop("action")
            item.pop("topic")
            dynamodb.put_item(TableName=DIM_TABLE,Item = item)
        if event["action"] == "status":
            item.pop("action")
            item.pop("topic")
            dynamodb.put_item(TableName=LCM_Status,Item = item)


def prepare_dict_data(data: dict) -> dict:
    """create dict item for database entry
    
    Parameters
    ----------
    data: dict
        request dict item which has to be prepared for db insertion

    Returns
    -------
    dict
        creates a item which can be added to the object
    """
    item = {}
    for key in data:
        if type(data[key]) == str:
            item[key] = {"S": data[key]}
        elif type(data[key]) == int:
            item[key] = {"N": f"{data[key]}"}
        elif type(data[key]) == float:
            item[key] = {"N": f"{data[key]}"}
        elif type(data[key]) == dict:
            item[key] = {"M": prepare_dict_data(data[key])}
        elif type(data[key]) == list:
            item[key] = {"L": prepare_list_data(data[key])}

    return item

def prepare_list_data(data: list) -> dict:
    """create list item for database entry
    
    Parameters
    ----------
    data: list
        request list item which has to be prepared for db insertion

    Returns
    -------
    dict
        Item which can be added to the object
    """
    item = []
    for ele in data:
        if type(ele) == str:
            item.append({"S": ele})
        elif type(ele) == int:
            item.append({"N": f"{ele}"})
        elif type(ele) == float:
            item.append({"N": f"{ele}"})
        elif type(ele) == dict:
            item.append({"M": prepare_dict_data(ele)})
        elif type(ele) == list:
            item.append({"L": prepare_list_data(ele)})

    return item
