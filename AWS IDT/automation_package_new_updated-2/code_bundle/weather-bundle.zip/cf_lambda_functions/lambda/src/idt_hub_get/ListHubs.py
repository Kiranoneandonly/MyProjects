import json
import boto3

client = boto3.client('iot')

def list_hub(event, context):
    """Provides a list of hubs registered.
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    # print(event)

    if(event['queryStringParameters']==None):

        response = client.list_things()
        if len(response['things']) ==0:
            return {
                'statusCode': 404,
                'body': json.dumps('Resourse not found')
            }
        print(response)
    
        return {
            'statusCode': 200,
            'body': json.dumps({'hubs': response['things']})
        }

    else:
        hubs = client.list_things()

        if len(hubs['things']) ==0:
            return {
                'statusCode': 404,
                'message': json.dumps('Resourse not found')
            }

        response = [x for x in hubs['things'] if determine_viablity(x,event['queryStringParameters'])]

        if len(response) == 0:
            print("Resourse not found response sending")
            return {
                'statusCode': 404,
                'body': json.dumps('Resourse not Found')
            }

        return{
            'statusCode': 200,
            'body': json.dumps({'hubs': response})
        }
            

def determine_viablity(hub: list,queryStringParam: list):
    """Provides a list of hubs registered.
    
    Parameters
    ----------
    hub : list
        list of hubs

    queryStringParam: list
        list of query parameters

    Returns
    -------
    json
        a response in a form of json
    """
    viablity = True
    if len(hub['attributes']) == 0:
        viablity = False
    for attrib in hub['attributes']:
                for key in queryStringParam:
                    if not key in attrib:
                        viablity = False
                    else:
                        if not hub['attributes'][key] == queryStringParam[key]:
                            viablity = False

    return viablity