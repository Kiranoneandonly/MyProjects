import json
import boto3

dynamodb = boto3.client('dynamodb')

TABLE_NAME = "LCMMaster"

accepted_queryStrings = ["key","ip","batch","year","month","day","weekday","hour","minute","second","mintime","maxtime","limit"]

def get_lamps(event, context):
    """Return the list of lamps
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)
    mapper= {}

    with open('mapper.json') as json_file:
        mapper = json.load(json_file)

    if(event['queryStringParameters']==None):

        result = dynamodb.scan(TableName=TABLE_NAME,Limit=10)

        print(result)

        if (not 'Items' in result) or result['Items']==0:
            return {
                'statusCode': 404,
                'body': json.dumps('Resourse not found')
            }

        response ={"lcm": []}

        for ele in result["Items"]:
            response["lcm"].append({
                "key": ele["primaryKey"]["S"],
                "firmware": ele["firmware"]["S"],
                "batch": ele["batch"]["S"],
                "ip": ele["ip"]["S"],
                "mfd": ele["mfd"]["M"]["timestamps"]["N"]
            })

        return {
                'statusCode': 200,
                'body': json.dumps(response)
            }

    else:
        result = {}
        request = process_query(event,mapper)
        print(request)
        method = request.pop("method")

        if method == "get_item":
            result = dynamodb.get_item(**request)
        elif method == "scan":
            result = dynamodb.scan(**request)

        print(result)
        
        if (not "Items" in result) or result["Items"] == None or len(result["Items"])==0:
            return {
                'statusCode': 404,
                'body': json.dumps('Resourse not found')
            }

        response ={"lcm": []}

        for ele in result["Items"]:
            response["lcm"].append({
                "key": ele["primaryKey"]["S"],
                "firmware": ele["firmware"]["S"],
                "batch": ele["batch"]["S"],
                "ip": ele["ip"]["S"],
                "mfd": ele["mfd"]["M"]["timestamps"]["N"]
            })
        
        return {
            'statusCode': 200,
            'body': json.dumps(response)
        }


def process_query(event, mapper) -> dict:
    """Return the prepared query and method name to be used for querying db
    
    Parameters
    ----------
    event : dict
        details related to html request

    mapper:
        html request and db mapping schema

    Returns
    -------
    dict
        a response in a form of json
    """
    item= {}
    item["TableName"] = TABLE_NAME
    FilterExpression = ""
    ExpressionAttributeValues ={}
    
    if "key" in event['queryStringParameters']:
        return {
                    "method": "get_item", 
                    "TableName": TABLE_NAME,
                    "Key": {
                        mapper[mapper["#primaryKey"]]["db"]: {"S": event['queryStringParameters'][mapper[mapper["#primaryKey"]]["request"]]}
                    }
                }

    if "limit" in event['queryStringParameters']:
        item["Limit"] = event['queryStringParameters']['limit']

    if "weekday" in event['queryStringParameters']:
        FilterExpression = FilterExpression+"mfd.weekdays=:mwd and "
        ExpressionAttributeValues[":mwd"]= {
            "N": event['queryStringParameters']['weekday']
        }

    if "mintime" in event['queryStringParameters']:
        if 'maxtime' in event['queryStringParameters']:
            FilterExpression = FilterExpression+"mfd.timestamps BETWEEN :mints AND :maxts and "
            ExpressionAttributeValues[":mints"] = {
                "N": event['queryStringParameters']['mintime']
            }
            ExpressionAttributeValues[":maxts"] = {
                "N": event['queryStringParameters']['maxtime']
            }
        else:
            FilterExpression = FilterExpression+"mfd.timestamps >= :mints and "
            ExpressionAttributeValues[":mints"]= {
                "N": event['queryStringParameters']['mintime']
            }
    else:
        if 'maxtime' in event['queryStringParameters']:
            FilterExpression = FilterExpression+"mfd.timestamps<=:maxts and "
            ExpressionAttributeValues[":maxts"] ={
                "N": event['queryStringParameters']['maxtime']
            }

    if "month" in event['queryStringParameters']:
        FilterExpression = FilterExpression+"mfd.months=:mmth and "
        ExpressionAttributeValues[":mmth"]= {
            "ComparisonOperator": "EQ",
            "AttributeValueList": [{"N": {event['queryStringParameters']['month']}}]
        }

    if "hour" in event['queryStringParameters']:
        FilterExpression = FilterExpression+"mfd.hours=:mhr and "
        ExpressionAttributeValues[":mhr"]= {
            "N": event['queryStringParameters']['hour']
        }

    if "batch" in event['queryStringParameters']:
        FilterExpression = FilterExpression+"batch=:bt and "
        ExpressionAttributeValues[":bt"]= {
            "S": event['queryStringParameters']['batch']
        }

    if "ip" in event['queryStringParameters']:
        FilterExpression = FilterExpression+"ip=:ip and "
        ExpressionAttributeValues[":ip"]= {
            "S": event['queryStringParameters']['ip']
        }

    if len(FilterExpression)>0:
        item["FilterExpression"] = FilterExpression[:-5]
        item["ExpressionAttributeValues"] = ExpressionAttributeValues
    if not "FilterExpression" in item:
        if not "Limit" in item:
            item["Limit"] = 10
    item["method"] = "scan"

    return item
