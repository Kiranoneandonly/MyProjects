import json
import boto3

dynamodb = boto3.client('dynamodb')

TABLE_NAME = 'LCM'

db_map = {}

def get_ip_lamp(event, context):
    """Get the lamps with the help of ip address
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)
    ip = event['pathParameters']['ipv6']
    print("ip: ",ip)
    
    with open('mapper.json') as json_file:
        db_map = json.load(json_file)
    
    result = dynamodb.scan(TableName=TABLE_NAME,ScanFilter={
        'ip': {
            'AttributeValueList': [
                {
                    'S': ip
                }
            ],
            'ComparisonOperator': 'EQ'
        }
    })

    print(result)

    lamp = result['Items']

    if lamp==None or len(lamp)==0:
        return {
            'statusCode': 404,
            'body': json.dumps(f"Resourse: {ip} not found")
        }
    
    lamps = populate_list(lamp, db_map)
    
    return {
        'statusCode': 200,
        'lamps': json.dumps(lamps)
    }


def populate_list(items: list, db_map: dict) -> list:
"""Return an Array populated with items according to the scehma specified
    
    Parameters
    ----------
    items : list
        list whose data needs to be duplicated

    db_map : dict
        schema in which way data will transformed, request is the target data while db is the way data is mentioned.

    Returns
    -------
    list
        list of items duplicated from items
    """
    Arr=[]

    for item in items:
        element = {}
        for map_element in db_map:
            if db_map[map_element]["db"] in item:
                for key in item[db_map[map_element]["db"]]:
                    element[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    if key=='S':
                        element[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key=='N':
                        element[db_map[map_element]["request"]] = float(item[db_map[map_element]["db"]][key])
                    elif key=='M':
                        element[db_map[map_element]["request"]] = populate_dict(item[db_map[map_element]["db"]][key],db_map[map_element]["map"])
                    elif key == 'SS':
                        element[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key == 'NS':
                        number_list = []
                        for ele in item[db_map[map_element]["db"]][key]:
                            number_list.append(float(ele))
                        element[db_map[map_element]["request"]] = number_list
        Arr.append(element)
    return Arr

def populate_dict(items: dict, db_map: dict) -> dict:
"""Return an dictionary populated with items according to the scehma specified
    
    Parameters
    ----------
    items : dict
        dict whose data needs to be duplicated

    db_map : dict
        schema in which way data will transformed, request is the target data while db is the way data is mentioned.

    Returns
    -------
    dict
        dict of items duplicated from items
    """
    itnr = {}
    for item in items:
        for map_element in db_map:
            if db_map[map_element]["db"] in item:
                for key in item[db_map[map_element]["db"]]:
                    itnr[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    if key=='S':
                        itnr[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key=='N':
                        itnr[db_map[map_element]["request"]] = float(item[db_map[map_element]["db"]][key])
                    elif key=='M':
                        itnr[db_map[map_element]["request"]] = populate_dict(item[db_map[map_element]["db"]][key],db_map[map_element]["map"])
                    elif key == 'SS':
                        itnr[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key == 'NS':
                        number_list = []
                        for ele in item[db_map[map_element]["db"]][key]:
                            number_list.append(float(ele))
                        itnr[db_map[map_element]["request"]] = number_list
    return itnr