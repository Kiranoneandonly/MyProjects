var AWS = require('aws-sdk');
//var iot = new AWS . IotData ( {endpoint: 'a2bhgm0pjpw0ar.iot.us-west-2.amazonaws.com' } )
var iot = new AWS . IotData ( {endpoint: 'a2aoegwed86tb9-ats.iot.us-west-2.amazonaws.com' } )
exports.handler = (event, context, callback) => {
    // TODO implement
  console . log ( event );
  var params = {
    topic: 'IDT-Test/Publish/Topic',
    payload: new Buffer ( event . body  ),
    qos: 0
  };
  iot . publish ( params, function ( err, data ) {
    if (err) console . log ( err, err . stack ); // an error occurred
    else {
      console . log ( "Success!" );
      callback(null, {
            statusCode: 201,
            body: JSON.stringify({
              Status: "done"
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            isBase64Encoded: false
        } );
    }
  });
  
};