import json
import boto3

iot = boto3.client('iot')

def get_hub(event, context):
    """Provides a attributes of the registered hub.
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)
    hubid = event['pathParameters']['hubid']

    response = None

    try: 
        response = iot.describe_thing(thingName=hubid)
        print(response)
    except Exception:
        return {
        "statusCode": 404,
        "body": json.dumps(f"Unable to find hub: {hubid}")
        }

    return {
        "statusCode": 200,
        "body": json.dumps({
            "hubid": hubid,
            "attributes": response["attributes"]
        })
    }