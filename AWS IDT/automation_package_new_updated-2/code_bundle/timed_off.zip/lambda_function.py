import json
import datetime
import boto3

iot = boto3.client('iot-data')
QOS = 0
DEFAULT_TRANSITION_TIME = 2

def lambda_handler(event, context):
    # TODO implement
    utc_now = datetime.datetime.utcnow() + datetime.timedelta(seconds=300)
    event_client = boto3.client('events')
    
    day = utc_now.date().day
    month = utc_now.date().month
    year = utc_now.date().year
    
    
    minute = utc_now.minute 
    print(minute)
    hour = utc_now.hour
    
    cron_expression = "cron("+str(minute)+" "+str(hour)+" " + str(day)+" " + str(month)+" " + "?"+" " + str(year) + ")"
    print(cron_expression)

    
    response = event_client.put_rule(
    Name='timed_off',
    ScheduleExpression=cron_expression )
    
    mt_group = "idt/group/groupone/dim"
    message = {"transition-time": DEFAULT_TRANSITION_TIME}
    message["level"] = 1000
    print("message formed and publishing to topic")
    iot.publish(
        topic= mt_group,
        qos=QOS,
        payload=json.dumps(message))
    
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        "headers": {
                    "Access-Control-Allow-Origin" : "*",
                     "Accept" : "application/json"
                    }
    }
