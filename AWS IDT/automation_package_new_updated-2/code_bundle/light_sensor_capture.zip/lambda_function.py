import boto3
import json

def lambda_handler(event, context):

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('lightSensor')

    event["ttl"] = int(event["timestamp"] + 172800)
    event["timestamp"] = str(int(event["timestamp"]))
    print(event)
    response = table.put_item(
        Item=event)
    return {
        'statusCode': 200,
        'body': json.dumps('post done !!'),
                         "headers": {
                    "Access-Control-Allow-Origin" : "*",
                     "Accept" : "application/json"
                    }
    }