import json
import boto3
import time
from validateBody import validate_body

iot = boto3.client('iot-data')
dynamodb = boto3.client('dynamodb')

LCM_TABLE = "LCM"
QOS = 0
RGB_MQTT_TOPIC = "idt/lcm/{ipv6}/rgb-dim" #was dim-rgb
request_schema = {}

def dim_rgb_put(event, context):
    """ saves the dim level in database and sends it to respective lcm
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)

    ipv6 = event['pathParameters']['ipv6']
    
    print(type(event['body']))
    print(f"body: {event['body']}")

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)

    event["body"].replace("\n ","")
    
    body = {}
    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        

    response = validate_body(body, request_schema)

    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)

    print("Checking lcm entry in db")

    db_result = dynamodb.scan(TableName=LCM_TABLE,ScanFilter={
        'ip': {
            'AttributeValueList': [
                {
                    'S': ipv6
                }
            ],
            'ComparisonOperator': 'EQ'
        }
    })

    print("db result: ",db_result)

    lcm = db_result['Items']

    if lcm==None or len(lcm)==0:
        print("Unable to find any associated lamp sending 404 response")
        return build_response(404,f"Resourse: {ipv6} not found")

    lcm[0]["rgb"] = {"M": {
            "red":{"N": body["red"]},
            "blue": {"N": body["blue"]},
            "green": {"N": body["green"]}
        }
    }

    save_to_db(lcm[0])
    inform_lcm(ipv6, body)
    return build_response(200,"success")

    

def save_to_db(lcm):
    """Save changes to database
    
    Parameters
    ----------
    lcm: dict
        a single lcm object or single lcm entry as in database

    """
    dynamodb.update_item(TableName = LCM_TABLE,  
        Key= {
            "primaryKey": lcm['primaryKey']
        },
        AttributeUpdates = {
            "rgb": {'Value': {
                "M": {
                    "red": {
                        "N": str(lcm["rgb"]["M"]["red"]["N"])
                    },
                    "blue": {
                        "N": str(lcm["rgb"]["M"]["blue"]["N"])
                    },
                    "green": {
                        "N": str(lcm["rgb"]["M"]["green"]["N"])
                    }
                }
            },
                'Action': 'PUT'
            },
        }
    )

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

def inform_lcm(ip, body):
    message = {
                "red": body["red"],
                "blue": body["blue"],
                "green": body["green"]
        }
    mt = RGB_MQTT_TOPIC.replace("{ipv6}",ip)
    print("sending mqtt message to: ", ip, " message: ", message)
    iot.publish(topic = mt,
        qos = QOS,
        payload= json.dumps(message))