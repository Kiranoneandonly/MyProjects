import json
import boto3

dynamodb = boto3.client('dynamodb')

GROUP_TABLE = "groupV2"
GROUP_LCM_TABLE = "GroupLcm"
GROUP_PROFILE_TABLE = "profileGroup"

def get_groups(event, context):
    """Return the list of groups
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)

    if(event['queryStringParameters']==None):
        group_result = dynamodb.scan(TableName=GROUP_TABLE)
        group_lcm_result = dynamodb.scan(TableName=GROUP_LCM_TABLE)
        group_profile_result = dynamodb.scan(TableName=GROUP_PROFILE_TABLE)

        groups = prepare_result(group_result['Items'], group_lcm_result['Items'], group_profile_result['Items'])

        return {
                'statusCode': 200,
                'body': json.dumps({'group': groups}),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

def prepare_lcm_list(group_lcm):
    group_lcm_map = {}
    for ele in group_lcm:
        if not ele['groupName']['S'] in group_lcm_map:
            group_lcm_map[ele['groupName']['S']] = []
        group_lcm_map[ele['groupName']['S']].append(ele['ip']['S'])
    print("prepare_lcm_list: lcm map length: ", len(group_lcm_map))
    return group_lcm_map


def prepare_groups(groups, group_lcm, profile_group):
    grps = []
    for group in groups:
        grp = {}
        grp['name'] = group['groupName']['S']
        if 'description' in group:
            grp['description'] = group['description']['S']
        if group['groupName']['S'] in profile_group:
            grp['profile'] = profile_group[group['groupName']['S']]
        if group['groupName']['S'] in group_lcm:
            grp['members'] = {}
            grp['members']['lcms'] = []
            grp['members']['lcms'] = group_lcm[group['groupName']['S']]
        grps.append(grp)
    print("prepare_group: group length: ",len(grps))
    return grps

def prepare_result(group, group_lcm, group_profile):
    lcm_map = prepare_lcm_list(group_lcm)
    profile_map = prepare_profile(group_profile)
    return prepare_groups(group, lcm_map, profile_map)
    
def prepare_profile(group_profile):
    groups = {}
    for item in group_profile:
        groups[item['groupName']['S']] = item['profile']['S']
    return groups