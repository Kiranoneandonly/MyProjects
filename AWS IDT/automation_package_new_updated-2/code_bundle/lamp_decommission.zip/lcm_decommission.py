import json
import boto3
import time

dynamodb = boto3.client('dynamodb')
iot_data = boto3.client('iot-data')

TABLE_NAME = 'LCM'
MQTT_TOPIC = "idt/hub/{hubid}/remove-lamp"
QOS = 0

def lcm_decommission(event,context):
    """Decommission a lamp
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """

    ipv6 = event['pathParameters']['ipv6']
    print("request to decommision of lcm: ",ipv6)

    print("Checking lcm entry in db")

    db_result = dynamodb.scan(TableName=TABLE_NAME,ScanFilter={
        'ip': {
            'AttributeValueList': [
                {
                    'S': ipv6
                }
            ],
            'ComparisonOperator': 'EQ'
        }
    })

    print("lcm from db: ",db_result)

    lcm = db_result['Items']

    if lcm==None or len(lcm)==0:
        return {
            'statusCode': 404,
            'body': json.dumps(f"Resourse: {ipv6} not found"),
            "headers": {
                "Access-Control-Allow-Origin" : "*",
                "Accept" : "application/json"
            }
        }

    lcm_id = lcm[0]["primaryKey"]["S"]
    hub_id = lcm[0]["hubid"]["S"]
    time_float = time.time()


    updated_values = dynamodb.update_item(TableName=TABLE_NAME,
    Key={
        'primaryKey': {
            'S': lcm_id
        }
    },
    ExpressionAttributeNames = {"#st": "status","#cp":"custom-properties","#ld":"lastDecommission"},
    ExpressionAttributeValues = {":stnew":{"S":"Decommissioned"},":ldnew":{"N":str(time_float)}},
    UpdateExpression = "SET #st= :stnew, #cp.#ld= :ldnew",
    ReturnValues= "UPDATED_NEW")

    print("updated values",updated_values)

    inform_hub_for_decommission_lamp(hub_id,ipv6)

    return {
        'statusCode': 201,
        'body': json.dumps('Luminaire Decommissioned')
    }


def inform_hub_for_decommission_lamp(hubid: str,lampip: str):
    """sends mqtt request to the hub for new lamp registration
    
    Parameters
    ----------
    hubid: str
        hubid assosiated with the lamp

    lampip: str
        ipv6 address of the lamp

    primary: str
        primary key of the lamp

    secondary: str
        secondary key of the lamp
    """
    mt = MQTT_TOPIC.replace("{hubid}",hubid)
    iot_data.publish(topic=mt,qos=QOS, payload=json.dumps({
        "address": lampip
    }))