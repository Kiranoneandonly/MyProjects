import numpy
from skyfield import api
from skyfield import almanac
from skyfield.api import Loader
import boto3


def get_utc_sunrise_sunset(t0,t1,bluffton):
	e = api.load('de421.bsp')
	t, y = almanac.find_discrete(t0, t1, almanac.sunrise_sunset(e, bluffton))
	return(t.utc_datetime(),y)

def get_utc_time():
	ts = api.load.timescale()
	t = ts.now()
	return t.utc_datetime()

def get_bluffton(longitude,latitude):
	longitude_dir = ""
	latitude_dir = ""
	if(longitude < 0):
		longitude_dir = ' S'
		longitude *= -1
	else :
		longitude_dir = ' N'

	if(latitude < 0):
		latitude_dir = ' W'
		latitude *= -1
	else :
		latitude_dir = ' E'
	return api.Topos(str(longitude)+longitude_dir, str(latitude)+latitude_dir)

def get_utc_now_time_pair():
	ts = api.load.timescale()
	current_time = get_utc_time()
	year = current_time.year
	month = current_time.month
	day = current_time.day
	t0 = ts.utc(year, month, day, 0)
	t1 = ts.utc(year, month, day, 23,59,59)
	return([t0,t1])

def is_day(t_arr,b_arr):
	ts = api.load.timescale()
	t_now = ts.now().utc_datetime()
	print(t_now)
	t_hour = t_now.hour
	t_min = t_now.minute
	total_now_minutes = t_hour*60 + t_min 
	if(b_arr[0] == False):
		total_sunrise_minutes = t_arr[1].hour * 60 + t_arr[1].minute
		total_sunset_minutes = t_arr[0].hour * 60 + t_arr[0].minute
		if(total_now_minutes > total_sunset_minutes and total_now_minutes < total_sunrise_minutes):
			return False
	else :
		total_sunrise_minutes = t_arr[0].hour * 60 + t_arr[0].minute
		total_sunset_minutes = t_arr[1].hour * 60 + t_arr[1].minute
		if(total_now_minutes > total_sunrise_minutes and total_now_minutes < total_sunset_minutes):
			return False

	return True


def lambda_handler(event, context):
	ts = api.load.timescale()
	bluffton = get_bluffton(37.2574466,-121.7849705)
	#59.8937806,10.6450355
	#bluffton = get_bluffton(5.3773123,100.3808622)
	#bluffton = get_bluffton(59.8937806,10.6450355)
	[t0,t1] = get_utc_now_time_pair()
	print(get_utc_sunrise_sunset(t0,t1,bluffton))
	[t_arr,b_arr] = get_utc_sunrise_sunset(t0,t1,bluffton)
	print(is_day(t_arr,b_arr))
	print(get_days_dim_map(12,12))
	return {
	'statusCode': 200,
	'body': ""
	}



def hour_arr_offset(hour_arr,offset):
	offset_hour_arr = li[offset:]+li[:offset]
	return(offset_hour_arr)

def day_dim_val(hour_arr,sunrise,sunset):
	ts = api.load.timescale()
	t_now = ts.now().utc_datetime()
	t_hour = t_now.hour
	t_min = t_now.minute
	print("dim "+hour_arr[t_hour]+" "+str(t_hour))
	return(hour_arr[t_hour])



def get_days_dim_map(sunrise,sunset):
	days_dim_map = {}
	dynamodb = boto3.resource('dynamodb')
	table = dynamodb.Table('day')
	response = table.scan()
	all_data = response["Items"]
	local_hour_arr = hour_arr_offset(day["hour"],-7)
	for day in all_data:
		print(day)
		print(day_dim_val(local_hour_arr,sunrise,sunset))
		days_dim_map[day["id"]] = day_dim_val(day["hour"],sunrise,sunset)

	print(days_dim_map)
	return(days_dim_map)



#lambda_handler(None, None)
#get_days_dim_map(12,12)