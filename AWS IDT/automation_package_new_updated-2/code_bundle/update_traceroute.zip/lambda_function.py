import json
import boto3
import decimal
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event, context):
    # TODO implement
    
    print(event)
    
    target = event["target"]
    target_last_4 = target[-5:].replace(':','')
    print(target_last_4)
    
    hop_1 = event["route"][0]["hop"][-5:].replace(':','')
    print(hop_1)
    
    rssi = event["route"][1]["rssi"]
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('LCM')
    fe = Key('ip').eq("fe80::211:7d00:30:"+target_last_4)
    pe = "primaryKey"

    response = table.scan(
    FilterExpression=fe,
    ProjectionExpression=pe
    )
    
    print(response)
    
    primary_key = response["Items"][0]["primaryKey"]
    
    response = table.update_item(
    Key={
        'primaryKey': primary_key
    },
    UpdateExpression="set uplink = :r, rssi=:p",
    ExpressionAttributeValues={
        ':r': "fe80::211:7d00:30:"+hop_1,
        ':p': rssi
    },
    ReturnValues="UPDATED_NEW"
    )
    
    print(response)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
