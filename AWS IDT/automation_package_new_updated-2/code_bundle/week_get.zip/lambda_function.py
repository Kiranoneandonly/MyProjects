
import boto3
import json

from boto3.dynamodb.conditions import Key, Attr

    
def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('week')
    response = table.scan()
    print(response["Items"])
    return  {
                'statusCode': 200,
                'body': json.dumps(response),
                 "headers": {
                    "Access-Control-Allow-Origin" : "*",
                     "Accept" : "application/json"
                    }

            }