import json
import boto3
import time
from validateBody import validate_body

dynamodb = boto3.client('dynamodb')

request_schema = {}
mapper = {}

IKE_TABLE = "ikeykeys"

def load_lcm(event, context):
    """Load IKE keys of the lamps
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """

    response = parse_request_body(event)
    if response["statusCode"] == 400:
        return response
    request_schema, mapper = initialize_mapper_and_schema()
    print("request_schema: ", request_schema)
    body = response["body"]
    response = validate_body(body, request_schema)
    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)
    save_in_db(body['lcms'],mapper)
    return build_response(200,{"message": "lcms loaded"})



def parse_request_body(event: dict):
    """Build and return response according to status code and message
    
    Parameters
    ----------
    event : dict
        details related to html request
        
    body:
        body of the html request

    Returns
    -------
    dict
        response of parsing
    """
    body = {}
    print(event)
    print(type(event['body']))

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)
        
    print(f"body: {event['body']}")
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")

    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    response = build_response(200,{"message":"success"})
    response["body"] = body
    return response


def initialize_mapper_and_schema():
    """ Initialize the request_schema object and mapper object"""
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
    return [request_schema, mapper]


def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }
            
def prepare_db_item(lcms, mapper):
    items = []
    for lcm in lcms:
        items.append({
            'PutRequest': { 'Item':{
                mapper['ip']['db']: {
                    "S": lcm[mapper['ip']['request']]
                },
                mapper['key']['db']: {
                    "S": lcm[mapper['key']['request']] 
                }
            }}
        })
    item = {IKE_TABLE: items}
    return item
    
def save_in_db(lcms,mapper):
    requestItems = prepare_db_item(lcms, mapper)
    print(requestItems)
    dynamodb.batch_write_item(RequestItems = requestItems)