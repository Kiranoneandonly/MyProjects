import numpy
from skyfield import api
from skyfield import almanac
from skyfield.api import Loader
import boto3
import json
import datetime


iot = boto3.client('iot-data')
dim_mqtt_topic = "idt/group/{group}/dim"
QOS = 0
DEFAULT_TRANSITION_TIME = 2
WEEK_TABLE = "week"
DAY_TABLE = "day"
PROFILE_GROUP_TABLE = "profileGroup"


def get_utc_sunrise_sunset(t0,t1,bluffton):
	e = api.load('de421.bsp')
	t, y = almanac.find_discrete(t0, t1, almanac.sunrise_sunset(e, bluffton))
	return(t.utc_datetime(),y)

def get_utc_time():
	ts = api.load.timescale()
	t = ts.now()
	return t.utc_datetime()

def get_bluffton(longitude,latitude):
	longitude_dir = ""
	latitude_dir = ""
	if(longitude < 0):
		longitude_dir = ' S'
		longitude *= -1
	else :
		longitude_dir = ' N'

	if(latitude < 0):
		latitude_dir = ' W'
		latitude *= -1
	else :
		latitude_dir = ' E'
	return api.Topos(str(longitude)+longitude_dir, str(latitude)+latitude_dir)

def get_utc_now_time_pair():
	ts = api.load.timescale()
	current_time = get_utc_time()
	year = current_time.year
	month = current_time.month
	day = current_time.day
	t0 = ts.utc(year, month, day, 0)
	t1 = ts.utc(year, month, day, 23,59,59)
	return([t0,t1])

def is_day(t_arr,b_arr):
	ts = api.load.timescale()
	t_now = ts.now().utc_datetime()
	#print(t_now)
	t_hour = t_now.hour
	t_min = t_now.minute
	total_now_minutes = t_hour*60 + t_min 
	if(b_arr[0] == False):
		total_sunrise_minutes = t_arr[1].hour * 60 + t_arr[1].minute
		total_sunset_minutes = t_arr[0].hour * 60 + t_arr[0].minute
		if(total_now_minutes > total_sunset_minutes and total_now_minutes < total_sunrise_minutes):
			return False
	else :
		total_sunrise_minutes = t_arr[0].hour * 60 + t_arr[0].minute
		total_sunset_minutes = t_arr[1].hour * 60 + t_arr[1].minute
		if(total_now_minutes > total_sunrise_minutes and total_now_minutes < total_sunset_minutes):
			return False

	return True


def lambda_handler(event, context):
	print("-----Cron Start-----")
	ts = api.load.timescale()
	bluffton = get_bluffton(37.2574466,-121.7849705)
	time_zone = -7

	# bluffton = get_bluffton(5.3773123,100.3808622)
	# time_zone = 8

	#bluffton = get_bluffton(59.8937806,10.6450355)

	[t0,t1] = get_utc_now_time_pair()
	[t_arr,b_arr] = get_utc_sunrise_sunset(t0,t1,bluffton)
	is_day(t_arr,b_arr)
	
	temp = get_days_dim_map(12,12,time_zone)
	print(temp)
	# mt = dim_mqtt_topic.replace("{group}","fe80::211:7d00:30:137e")
	# mt_group = "idt/group/groupone/dim"
	# message = {"transition-time": DEFAULT_TRANSITION_TIME}
	# message["level"] = temp["day1"]
	# if(is_day(t_arr,b_arr) == True):
	# 	message["level"] = 0
	# else:
	# 	message["level"] = temp["day1"]
	# print("message formed and publishing to topic")
	# iot.publish(
    #     topic= mt_group,
    #     qos=QOS,
    #     payload=json.dumps(message))
	gd = get_group_day_profile(time_zone)
	dp = get_day_profies(time_zone)
	gt = prepare_group_time_value(gd, dp)
	send_mqtt(gt, dim_mqtt_topic, QOS, is_day(t_arr,b_arr))

	print("-----Cron End-------")
	return {
	'statusCode': 200,
	'body': ""
	}



def get_week_profiles():
	week_profiles = {}
	dynamodb = boto3.client('dynamodb')
	query = {"TableName": WEEK_TABLE}
	weeks = dynamodb.scan(**query)
	if 'Items' in weeks and len(weeks['Items'])>0:
		for item in weeks['Items']:
			name = item['id']['S']
			days = item['hour']['L']
			week_profiles [name] = [days[0]["S"], days[1]["S"], days[2]["S"], days[3]["S"], days[4]["S"], days[5]["S"], days[6]["S"]]
	print(week_profiles)
	return week_profiles

def get_Weekday(timezone):
	utc_weekday = datetime.datetime.utcnow().weekday()
	utc_hour = datetime.datetime.utcnow().hour
	if (utc_hour + timezone < 0):
		if utc_weekday == 0:
			return 6
		return utc_weekday - 1
	if (utc_hour + timezone > 23):
		if utc_weekday == 6:
			return 0
		return utc_weekday + 1 			# should be utc_weekday + 1, was -1
	return utc_weekday

def get_local_hour(timezone):
	utc_hour = datetime.datetime.utcnow().hour
	diff = utc_hour + timezone
	if (diff < 0):
		return int(24 + diff) 			#should be 24 + diff, was 24 - diff
	if (diff > 23):
		return int(diff - 24)
	return utc_hour	+ timezone	    		# should be diff or utc_hour + timezone, was utc_hour only

def get_group_day_profile(timezone):
	week = get_week_profiles()
	group_day = {}
	weekday = get_Weekday(timezone)
	dynamodb = boto3.client('dynamodb')
	query = {"TableName": PROFILE_GROUP_TABLE}
	profileGroup = dynamodb.scan(**query)
	if 'Items' in profileGroup and len(profileGroup['Items'])>0:
		for item in profileGroup['Items']:
			profile = item['profile']['S']
			group_day[item['groupName']['S']] = week[profile][weekday]
	print(group_day)
	return group_day

def get_day_profies(timezone):
	day_time_values = {}
	hour = get_local_hour(timezone)
	dynamodb = boto3.client('dynamodb')
	query = {"TableName": DAY_TABLE}
	dayProfile = dynamodb.scan(**query)
	if 'Items' in dayProfile and len(dayProfile['Items'])>0:
		for item in dayProfile['Items']:
			day_time_values[item["id"]["S"]] = item["hour"]["L"][hour]["S"]
	return day_time_values

def prepare_group_time_value(group_day, day_time_val):
	gt_val = {}
	for group in group_day:
		gt_val[group] = day_time_val[group_day[group]]
	return gt_val

def send_mqtt(group_time, topic, qos, isDay):
	for group in group_time:
		mt = dim_mqtt_topic.replace("{group}",group)
		dim_val = int(group_time[group])*10
		message = {"transition-time": DEFAULT_TRANSITION_TIME}
		message["level"] = dim_val
		if(isDay):
			message["level"] = 0
		iot.publish(
        topic= mt,
        qos=QOS,
        payload=json.dumps(message))


def hour_arr_offset(hour_arr,offset):
	offset_hour_arr = hour_arr[offset:]+hour_arr[:offset]
	return(offset_hour_arr)

def day_dim_val(hour_arr,sunrise,sunset,time_zone):
	ts = api.load.timescale()
	t_now = ts.now().utc_datetime()
	t_hour = t_now.hour
	t_min = t_now.minute
	print("Local Time hour:"+ str((t_hour+time_zone)%24) + " min:"+str(t_min))
	return(hour_arr[t_hour])



def get_days_dim_map(sunrise,sunset,time_zone):
	days_dim_map = {}
	dynamodb = boto3.resource('dynamodb')
	table = dynamodb.Table('day')
	response = table.scan()
	all_data = response["Items"]	
	for day in all_data:
		local_hour_arr = hour_arr_offset(day["hour"],time_zone)
		days_dim_map[day["id"]] = day_dim_val(local_hour_arr,sunrise,sunset,time_zone)

	return(days_dim_map)



#lambda_handler(None, None)
#get_days_dim_map(12,12)