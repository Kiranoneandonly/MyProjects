import json
import boto3

dynamodb = boto3.client('dynamodb')

TABLE_NAME = "DimHistory"

def get_lamp_status(event, context):
    """Return the list of lamps
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)
    mapper= {}

    with open('mapper.json') as json_file:
        mapper = json.load(json_file)

    if(event['queryStringParameters']==None):

        result = dynamodb.scan(TableName=TABLE_NAME,Limit=50)

        print(result)

        if (not 'Items' in result) or result['Items']==0:
            return {
                'statusCode': 404,
                'body': json.dumps('Resourse not found'),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

        response ={"status": []}

        for ele in result["Items"]:
            response["status"].append({
                "timestamp": ele["timestamp"]["N"],
                "ip": ele["ip"]["S"],
                "level": ele["confirmed"]["M"]["level"]["N"]
            })

        return {
                'statusCode': 200,
                'body': json.dumps(response),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

    else:
        result = {}
        request = process_query(event,mapper)
        print(request)
        method = request.pop("method")

        if method == "get_item":
            result = dynamodb.get_item(**request)
        elif method == "scan":
            result = dynamodb.scan(**request)
        elif method == "query":
            result = dynamodb.query(**request)

        print(result)
        
        if (not "Items" in result) or result["Items"] == None or len(result["Items"])==0:
            return {
                'statusCode': 404,
                'body': json.dumps('Resourse not found'),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

        response ={"status": []}

        for ele in result["Items"]:
            response["status"].append({
                "timestamp": ele["timestamp"]["N"],
                "ip": ele["ip"]["S"],
                "level": ele["confirmed"]["M"]["level"]["N"]
            })
        
        return {
            'statusCode': 200,
            'body': json.dumps(response),
            "headers": {
                "Access-Control-Allow-Origin" : "*",
                "Accept" : "application/json"
            }
        }


def process_query(event, mapper) -> dict:
    """Return the prepared query and method name to be used for querying db
    
    Parameters
    ----------
    event : dict
        details related to html request

    mapper:
        html request and db mapping schema

    Returns
    -------
    dict
        a response in a form of json
    """
    item= {}
    item["TableName"] = TABLE_NAME
    FilterExpression = ""
    ExpressionAttributeValues ={}
    ExpressionAttributeNames = {}
    
    if "ip" in event['queryStringParameters']:
        item = makeKeyConditionExpression(event, mapper)
        if "ExpressionAttributeValues" in item:
            ExpressionAttributeValues = item["ExpressionAttributeValues"]
        if "ExpressionAttributeNames" in item:
            ExpressionAttributeNames = item["ExpressionAttributeNames"]
        item["TableName"] = TABLE_NAME
    else:
        if "mintime" in event['queryStringParameters']:
            ExpressionAttributeNames["#ts"] = "timestamp"
            if 'maxtime' in event['queryStringParameters']:
                FilterExpression = FilterExpression+"#ts BETWEEN :mints AND :maxts and "
                ExpressionAttributeValues[":mints"] = {
                    "N": event['queryStringParameters']['mintime']
                }
                ExpressionAttributeValues[":maxts"] = {
                    "N": event['queryStringParameters']['maxtime']
                }
            else:
                FilterExpression = FilterExpression+"#ts >= :mints and "
                ExpressionAttributeValues[":mints"]= {
                    "N": event['queryStringParameters']['mintime']
                }
        else:
            if 'maxtime' in event['queryStringParameters']:
                ExpressionAttributeNames["#ts"] = "timestamp"
                FilterExpression = FilterExpression+"#ts <= :maxts and "
                ExpressionAttributeValues[":maxts"] ={
                    "N": event['queryStringParameters']['maxtime']
                }

    if "limit" in event['queryStringParameters']:
        item["Limit"] = event['queryStringParameters']['limit']

    if "weekday" in event['queryStringParameters']:
        ExpressionAttributeNames["#wd"] = "weekday"
        ExpressionAttributeNames["#dt"] = "date"
        FilterExpression = FilterExpression+"#dt.#wd=:mwd and "
        ExpressionAttributeValues[":mwd"]= {
            "N": event['queryStringParameters']['weekday']
        }

    if "month" in event['queryStringParameters']:
        ExpressionAttributeNames["#mth"] = "month"
        ExpressionAttributeNames["#dt"] = "date"
        FilterExpression = FilterExpression+"#dt.#mth=:mmth and "
        ExpressionAttributeValues[":mmth"]= {
            "ComparisonOperator": "EQ",
            "AttributeValueList": [{"N": {event['queryStringParameters']['month']}}]
        }

    if "hour" in event['queryStringParameters']:
        ExpressionAttributeNames["#hr"] = "hour"
        ExpressionAttributeNames["#dt"] = "date"
        FilterExpression = FilterExpression+"#dt.#hr=:mhr and "
        ExpressionAttributeValues[":mhr"]= {
            "N": event['queryStringParameters']['hour']
        }

    if "day" in event['queryStringParameters']:
        ExpressionAttributeNames["#dy"] = "day"
        ExpressionAttributeNames["#dt"] = "date"
        FilterExpression = FilterExpression+"#dt.#dy=:mdy and "
        ExpressionAttributeValues[":mdy"]= {
            "N": event['queryStringParameters']['hour']
        }
    
    if "level" in event['queryStringParameters']:
        ExpressionAttributeNames["#lvl"] = "level"
        item["ExpressionAttributeNames"] = {"#lvl": "level"}
        FilterExpression = FilterExpression+"confirmed.#lvl=:lvl and "
        ExpressionAttributeValues[":lvl"]= {
            "N": event['queryStringParameters']['level']
        }

    if len(FilterExpression)>0:
        item["FilterExpression"] = FilterExpression[:-5]
        item["ExpressionAttributeValues"] = ExpressionAttributeValues
    if (not "FilterExpression" in item) or (not "KeyConditionExpression" in item):
        if not "Limit" in item:
            item["Limit"] = 10

    if not len(ExpressionAttributeNames) ==0:
        item["ExpressionAttributeNames"] = ExpressionAttributeNames

    if "KeyConditionExpression" in item:
        item["method"] = "query"
    else:
        item["method"] = "scan"

    return item


def makeKeyConditionExpression(event, mapper):
    item = {}
    ExpressionAttributeNames = {}
    epxAttribVal = {}
    pk = mapper[mapper["#partitionKey"]]["db"]

    expr = "ip=:ip"
    epxAttribVal[":ip"] = {
        "S": ""+event['queryStringParameters'][pk]
    }

    if "mintime" in event['queryStringParameters']:
        ExpressionAttributeNames = {"#ts": "timestamp"}
        if 'maxtime' in event['queryStringParameters']:
            expr = expr+" and #ts BETWEEN :mints AND :maxts"
            epxAttribVal[":mints"] = {
                "N": event['queryStringParameters']['mintime']
            }
            epxAttribVal[":maxts"] = {
                "N": event['queryStringParameters']['maxtime']
            }
        else:
            expr = expr+" and #ts >= :mints"
            epxAttribVal[":mints"]= {
                "N": event['queryStringParameters']['mintime']
            }
    else:
        if 'maxtime' in event['queryStringParameters']:
            ExpressionAttributeNames = {"#ts": "timestamp"}
            expr = expr+" and #ts <=:maxts"
            epxAttribVal[":maxts"] ={
                "N": event['queryStringParameters']['maxtime']
            }

    item["KeyConditionExpression"] = expr
    item["ExpressionAttributeValues"] = epxAttribVal
    if not len(ExpressionAttributeNames) ==0:
        item["ExpressionAttributeNames"] = ExpressionAttributeNames

    return item