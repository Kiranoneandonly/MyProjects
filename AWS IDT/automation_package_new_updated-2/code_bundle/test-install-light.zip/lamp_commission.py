import json
import boto3
import random
import time
from validateBody import validate_body

dynamodb = boto3.client('dynamodb')
iot_data = boto3.client('iot-data')
iot = boto3.client('iot')

LCM_TABLE_NAME = "LCM"
HUB_TABLE_NAME = "Hub"
IKE_TABLE = "ikeykeys"

MQTT_TOPIC="idt/hub/{hubid}/add-lamp"
QOS = 0
SECONDARY_KEY_LENGTH = 10

request_schema = {}
request_db_map = {}

def commission(event, context):
    """Commission a new lamp
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """

    ipv6 = event['pathParameters']['ipv6']
    print(ipv6)

    print(event)
    print(type(event['body']))

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)
        
    print(f"body: {event['body']}")
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")

    body = {}
    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})

    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        

    with open('mapper.json') as json_file:
        request_db_map = json.load(json_file)

    response = validate_body(body, request_schema)

    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)

    if not check_hub_registration(body[request_db_map["hubid"]["request"]]):
        return build_response(400,{
                "illigalValues": [{ "hubid": {"found": body[request_db_map["hubid"]["request"]]}, "message": "Unable to find specified hubid registered"}]
            })

    secondary_key = generate_secondary_key(body[request_db_map['longitude']["request"]],body[request_db_map['latitude']["request"]])
    secondary_key = "SK-"+secondary_key
    body["secondaryKey"] = secondary_key # adding secondary Key to the body 
    body["ip"] = ipv6
    body["status"] = "commissioning started"
    body["custom-properties"] = {}
    body["custom-properties"]["lastCommissionTimeStamp"] = time.time()
    body["custom-properties"]["commissionStep"] = 1

    item = create_db_item(body, request_db_map)
    print("database item: ",item)
    response = dynamodb.put_item(TableName = LCM_TABLE_NAME, Item= item)

    inform_hub_for_new_lamp(body[request_db_map["hubid"]["request"]], ipv6, body[request_db_map["primary"]["request"]], secondary_key)

    return build_response(201,{"message": "Lamp entry Created"})



def check_hub_registration(hubid: str) -> bool:
    """Return the hub associated with the lamp.
    
    Parameters
    ----------
    hubid : str
        hubid which needs to be checked in the database

    Returns
    -------
    bool
        status of hub registration in the database. 
        True    : Registered
        False   : Not registered
    """
    result = None

    try : 
        result = iot.describe_thing(thingName=hubid)
        print("hubid check result: ",result)
        return True
    except Exception:
        return False

    if result['thingName']== hubid:
        return True
    else:
        return False




def generate_secondary_key(longitude: float, latitude: float) -> str:
    """generate secondary key for lamp
    
    Parameters
    ----------
    longitude: float
        Longitude value of the commisioning lamp

    latitude: float
        Latitude value of the commsioning lamp

    Returns
    -------
    str
        secondary id for the lamp
    """
    longitude_decimal = longitude%1
    latitude_decimal = latitude%1

    longitude_decimal = int(longitude_decimal * 1000000)
    latitude_decimal = int(latitude_decimal * 1000000)

    longitude_decimal = longitude_decimal%100
    latitude_decimal = latitude_decimal%100

    time_float = time.time()
    time_float = time_float%1
    time_float = int(time_float*1000000)
    time_float = time_float%1000

    random_seed = f"{longitude_decimal}{latitude_decimal}{time_float}"

    random_seed = int(random_seed)
    random.seed(random_seed)
    random_key = "".join(random.choice('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ') for i in range(SECONDARY_KEY_LENGTH))
    return random_key


def create_db_item(body: dict, dbmap: dict) -> dict:
    """prepare item for database
    
    Parameters
    ----------
    body: dict
        request body which item has to be created

    dbmap: dict
        database mapping with of the request object

    Returns
    -------
    dict
        creates a item which can be added to the object
    """
    databasebody = {}
    mapKeys = dbmap.keys()

    for key in mapKeys:
        if dbmap[key]["request"] in body:
            if type(body[dbmap[key]["request"]]) is str:
                databasebody[dbmap[key]["db"]] = create_string_item(body[dbmap[key]["request"]])
            elif type(body[dbmap[key]["request"]]) is int:
                databasebody[dbmap[key]["db"]] = create_number_item(body[dbmap[key]["request"]])
            elif type(body[dbmap[key]["request"]]) is float:
                databasebody[dbmap[key]["db"]] = create_number_item(body[dbmap[key]["request"]])
            elif type(body[dbmap[key]["request"]]) is dict:
                if "map" in dbmap[key]:
                    databasebody[dbmap[key]["db"]] = {"M": create_db_item(body[dbmap[key]["request"]],dbmap[key]["map"])}
                else:
                    databasebody[dbmap[key]["db"]] = {"M": create_dict_item(body[dbmap[key]["request"]])}
            elif type(body[dbmap[key]["request"]]) is list:
                databasebody[dbmap[key]["db"]] = create_list_item(body[dbmap[key]["request"]])

    return databasebody
    
def get_ike_key(ip):
    print("get_ike_key: ip:",ip)
    ike1 = None
    result = dynamodb.get_item(TableName=IKE_TABLE, 
        Key={
            "ip": {
                "S": ip
            }
        })
    print("get_ike_key: result: ",result)
    if 'Item' in result and len(result['Item'])>0:
            ike1 = result['Item']['ike1']['S']
    else:
        ike1 = 'YWJjZGVmZ2hpamtsbW5vcA=='
    return ike1


def create_string_item(item: str) -> dict:
    """create a string item for database entry
    
    Parameters
    ----------
    item: str
        request item which has to be prepared for db insertion

    Returns
    -------
    dict
        Item which can be added to the object
    """
    return {
        "S": item
    }

def create_number_item(item) -> dict:
    """create numeric item for database entry
    
    Parameters
    ----------
    item: int, float
        request numeric item which has to be prepared for db insertion

    Returns
    -------
    dict
        Item which can be added to the object
    """
    return {
        "N": str(item)
    }

def create_list_item(item: list) -> dict:
    """create list item for database entry
    
    Parameters
    ----------
    item: list
        request list item which has to be prepared for db insertion

    Returns
    -------
    dict
        Item which can be added to the object
    """
    list_content = []
    list_item = {
        "L": list_content
    }
    for element in  item:
        if type(element) is str:
            list_content.append(create_string_item(element))
        elif type(element) is int:
            list_content.append(create_number_item(element))
        elif type(element) is float:
            list_content.append(create_number_item(element))
        elif type(element) is dict:
            list_content.append(create_dict_item(element))
        elif type(element) is list:
            list_content.append(create_list_item(element))

    return list_item

def create_dict_item(item: dict) -> dict:
    """create dict item for database entry
    
    Parameters
    ----------
    item: str
        request dict item which has to be prepared for db insertion

    Returns
    -------
    dict
        creates a item which can be added to the object
    """
    dict_content = {}
    dict_item = {
        "M": dict_content
    }
    for key in item.keys():
        if type(item[key]) is str:
            dict_content[key] = create_string_item(item[key])
        elif type(item[key]) is int:
            dict_content[key] = create_number_item(item[key])
        elif type(item[key]) is float:
            dict_content[key] = create_number_item(item[key])
        elif type(item[key]) is dict:
            dict_content[key] = create_dict_item(item[key])
        elif type(item[key]) is list:
            create_dict_item(item[key])
    return dict_item

def inform_hub_for_new_lamp(hubid: str,lampip: str, primary: str, secondary: str):
    """sends mqtt request to the hub for new lamp registration
    
    Parameters
    ----------
    hubid: str
        hubid assosiated with the lamp

    lampip: str
        ipv6 address of the lamp

    primary: str
        primary key of the lamp

    secondary: str
        secondary key of the lamp
    """
    mt = MQTT_TOPIC.replace("{hubid}",hubid)
    iot_data.publish(topic=mt,qos=QOS, payload=json.dumps({
        "address": lampip,
        # "key1": primary,
        # "key2": secondary
        "ike1": get_ike_key(lampip),
        "ike2": ""
    }))

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }