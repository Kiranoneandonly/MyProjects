import json
import boto3
import time
from validateBody import validate_body

iot = boto3.client('iot-data')
dynamodb = boto3.client('dynamodb')

LCM_TABLE = "LCM"
IKE_TABLE = "ikeykeys"
LCM_STATUS_TABLE = "LCMStatus"
DEFAULT_TRANSITION_TIME = 2
QOS = 0
LAMP_DIM_LEVEL_RANGE = [0,1000]
# message = {}
dim_mqtt_topic = "idt/lcm/{ipv6}/dim"
register_mqtt_topic = "idt/hub/{hubid}/add-lamp"
request_schema = {}
mapper = {}

# keys are used in python code
# values are used in http and mqtt
# index 0 is http, index 1 is mqtt
http_mqtt_mapping = { 
    "level": ["level","level"],
    'transition-time': ['transition-time','time']
    } 

def set_dim(event, context):
    """Check the where the dim command has to be routed and then route it to the correct hub.
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)

    ipv6 = event['pathParameters']['ipv6']
    
    print(type(event['body']))
    print(f"body: {event['body']}")

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)

    event["body"].replace("\n ","")
    
    body = {}
    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
        

    response = validate_body(body, request_schema)

    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)

    print("Checking lcm entry in db")

    db_result = dynamodb.scan(TableName=LCM_TABLE,ScanFilter={
        'ip': {
            'AttributeValueList': [
                {
                    'S': ipv6
                }
            ],
            'ComparisonOperator': 'EQ'
        }
    })

    print("db result: ",db_result)

    lcm = db_result['Items']

    if lcm==None or len(lcm)==0:
        print("Unable to find any associated lamp sending 404 response")
        return build_response(404,f"Resourse: {ipv6} not found")

    lcm_status = lcm[0]["status"]["S"]
    
    print("lcm status: ", lcm_status)
    if lcm_status == "decommissioned":
        print("lcm decommissioned sending 405 not allowed response")
        return build_response(405, {"message": "Lamp decommissioned, dimming not allowed"})

    print("preparing MQTT topic and body")
    mt = dim_mqtt_topic.replace("{ipv6}",ipv6)
    message = {"transition-time": DEFAULT_TRANSITION_TIME}
    message = build_message(body,message,mapper)

    if lcm_status == "online":              # first
        print("LCM online sending MQTT request")
        iot.publish(
            topic= mt,
            qos=QOS,
            payload=json.dumps(message))
    #    return build_response(200,{"message":"Success"})

    # if lcm_status == "commissioning started":
    print("LCM status:", lcm_status)
    print()
    lcm_step = int(lcm[0]["custom-properties"]["M"]["commissionStep"]["N"])
    last_commissioned = lcm[0]["custom-properties"]["M"]["lastCommission"]["N"]
    hub_id = lcm[0]["hubid"]["S"]
    lcm_ike1 = lcm[0]["primaryKey"]["S"]
    lcm_ike2 = lcm[0]["secondaryKey"]["S"]

    print("fetching previous lcm statuses")
    lcm_statuses = get_last_lamp_Status(ipv6,last_commissioned)

    print("lcm hub registration history: ",lcm_statuses)
    if lcm_status != "online": 
        reg_mt = register_mqtt_topic.replace("{hubid}",hub_id)
        if lcm_statuses == None or len(lcm_statuses)==0:
            new_ike1 = get_ike_key(ipv6)
            print("sending mqtt registration request")
            iot.publish(topic = reg_mt,
                qos = QOS,
                payload= json.dumps({
                    "address": ipv6,
                    "ike1": new_ike1,
                    "ike2": ""
            }))
            
        print("incrementing steps taken")
        update_steps(lcm_ike1,lcm_step+1)

        print("sending mqtt dim request")       
        iot.publish(
                topic= mt,
                qos=QOS,
                payload=json.dumps(message))

        # adder 2 ++++++++++++++++++++++++++++++++++++++++++
        
    if hub_id == "Penang1":
        hub_id = "Penang2"
            
        if lcm_status != "online":
            reg_mt = register_mqtt_topic.replace("{hubid}",hub_id)
        #    if lcm_statuses == None or len(lcm_statuses)==0:
            new_ike1 = get_ike_key(ipv6)
            print("sending mqtt registration request ")             
            iot.publish(topic = reg_mt,
                        qos = QOS,
                        payload= json.dumps({
                        "address": ipv6,
                        "ike1": new_ike1,
                        "ike2": ""
                    }))
                
            print("lcm status 2: ", lcm_status)
    
        print("preparing MQTT topic and body 2")
        mt = dim_mqtt_topic.replace("{ipv6}",ipv6)
        message = {"transition-time": DEFAULT_TRANSITION_TIME}
        message = build_message(body,message,mapper)

        print("sending mqtt dim request 2")     
        iot.publish(
                    topic= mt,
                    qos=QOS,
                    payload=json.dumps(message))    


        #adder +++++++++++++++++++++++++++++++++++++++++++++
        
    #    if ((hub_id == "Penang1") or (hub_id == "Penang2")):
    #        lcm_status = lcm[1]["status"]["S"]
    #        hub_id = lcm[1]["hubid"]["S"]
    #        
    #        iot.publish(topic = reg_mt,
    #            qos = QOS,
    #            payload= json.dumps({
    #            "address": ipv6,
    #            "ike1": new_ike1,
    #            "ike2": ""
    #        }))
    #            
    #        print("lcm status 2: ", lcm_status)
    #
    #        print("preparing MQTT topic and body")
    #        mt = dim_mqtt_topic.replace("{ipv6}",ipv6)
    #        message = {"transition-time": DEFAULT_TRANSITION_TIME}
    #        message = build_message(body,message,mapper)
    #    
    #        iot.publish(
    #                topic= mt,
    #                qos=QOS,
    #                payload=json.dumps(message))    
        # end of adder +++++++++++++++++++++++++++++++++++++

    #    return build_response(200,{"message":"Success"})
        
        
    print("registration confirmation present in database, setting status to online")
    set_status(lcm_ike1,"online")


  #  print("sending mqtt dim request")
  #  iot.publish(
  #      topic= mt,
  #      qos=QOS,
  #      payload=json.dumps(message))
    return build_response(200,{"message":"Success"})  
        

def build_message(body: dict, message: dict, mapper: dict):
    print(mapper)
    print(body)
    print(message)
    for key in mapper:
        if mapper[key]["request"] in body:
            if key == "level":
                message[mapper["level"]["mqtt"]] = int(body[mapper["level"]["request"]]*10)
            else:
                message[mapper[key]["mqtt"]] = body[mapper[key]["request"]]
    return message



def set_status(lcm_id: str, status: str):
    time_float = time.time()
    updated_values = dynamodb.update_item(TableName=LCM_TABLE,
    Key={
        'primaryKey': {
            'S': lcm_id
        }
    },
    ExpressionAttributeNames = {"#st": "status","#cp":"custom-properties","#fo":"firstOnline"},
    ExpressionAttributeValues = {":stnew":{"S":status},":fonew":{"N":str(time_float)}},
    UpdateExpression = "SET #st= :stnew, #cp.#fo= :fonew",
    ReturnValues= "UPDATED_NEW")
    return updated_values

    

def update_steps(lcm_id: str,lcm_step: int):
    updated_values = dynamodb.update_item(TableName=LCM_TABLE,
    Key={
        'primaryKey': {
            'S': lcm_id
        }
    },
    ExpressionAttributeNames = {"#stp": "commissionStep","#cp":"custom-properties"},
    ExpressionAttributeValues = {":stpnew":{"N":str(lcm_step)}},
    UpdateExpression = "SET #cp.#stp= :stpnew",
    ReturnValues= "UPDATED_NEW")
    return updated_values





def get_last_lamp_Status(ipv6: str, ts: float):
    result = dynamodb.query(TableName=LCM_STATUS_TABLE,
    ExpressionAttributeNames = {"#ip":"ip", "#ts": "timestamp"},
    ExpressionAttributeValues = { ":ipv6":{"S":ipv6},":timeval":{"N": str(ts)}},
    KeyConditionExpression = "#ip = :ipv6 AND #ts >= :timeval"
    )

    return result["Items"]


    

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }
            
def get_ike_key(ip):
    print("get_ike_key: ip:",ip)
    ike1 = None
    result = dynamodb.get_item(TableName=IKE_TABLE, 
        Key={
            "ip": {
                "S": ip
            }
        })
    print("get_ike_key: result: ",result)
    if 'Item' in result and len(result['Item'])>0:
            ike1 = result['Item']['ike1']['S']
    else:
        ike1 = 'YWJjZGVmZ2hpamtsbW5vcA=='
    return ike1