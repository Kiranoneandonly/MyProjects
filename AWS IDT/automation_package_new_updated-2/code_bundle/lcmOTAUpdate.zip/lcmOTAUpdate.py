import json
import boto3
import time
from validateBody import validate_body

iot = boto3.client('iot-data')
dynamodb = boto3.client('dynamodb')

dim_mqtt_topic = "idt/lcm/{ipv6}/update"
QOS = 0

request_schema = {}
mapper = {}
message = {}

def ota_update(event, context):

    ipv6 = event['pathParameters']['ipv6']

    print(type(event['body']))
    print(f"body: {event['body']}")

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)

    event["body"].replace("\n ","")
    
    body = {}
    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
        
    response = validate_body(body, request_schema)

    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)


    mt = dim_mqtt_topic.replace("{ipv6}",ipv6)
    message = build_message(body, mapper)

    # print(build_message(body, message, mapper))

    print("mqtt payload: ",message)

    iot.publish(
            topic= mt,
            qos=QOS,
            payload=json.dumps(message))

    return build_response(200,{"message":"Success"})




def build_message(body: dict,mapper: dict) -> dict:
    """Build and return mqtt message according to mapper and body and fills in message provided
    
    Parameters
    ----------
    body: dict
        request body
        
    message: dict
        dict in which message has to be written

    mapper: dict
        maps body and message fields

    Returns
    -------
    dict
        mqt message payload
    """
    for key in mapper:
        if mapper[key]["request"] in body:
            message[mapper[key]["mqtt"]] = body[mapper[key]["request"]]
    return message

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }