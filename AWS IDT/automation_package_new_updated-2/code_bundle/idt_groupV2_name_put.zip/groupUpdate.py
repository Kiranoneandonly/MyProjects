import json
import boto3
import time
from validateBody import validate_body

dynamodb = boto3.client('dynamodb')
iot_data = boto3.client('iot-data')

request_schema = {}
mapper = {}

GROUP_TABLE = "groupV2"
LCM_TABLE = "LCM"
GROUP_LCM_TABLE = "GroupLcm"
GROUP_GROUP_TABLE = "GroupGroup"

QOS = 0
MQTT_TOPIC = "idt/hub/{hubid}/group-update"

def update_group(event, context):
    """Commission a new lamp
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    groupName = event['pathParameters']['name']
    
    response = parse_request_body(event)
    if response["statusCode"] == 400:
        return response
    request_schema, mapper = initialize_mapper_and_schema()
    print("request_schema: ", request_schema)
    body = response["body"]
    body['name'] = groupName
    response = validate_body(body, request_schema)
    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)
    if not( 'add' in body or 'remove' in body):
        return build_response(400, {
            "message": "Bad Request! Please check other fields for more details",
            "missingValues": ['add', 'remove']
            })
    groupExists = get_group(groupName)
    if(groupExists["statusCode"]==400):
        return build_response(400, {
            "message": "Requested group does not exist",
            "found": groupName
            })
    group = groupExists["group"]
    pre_lcms = get_group_lcm(groupName)
    db_item = {}
    if("add" in body):
        response = check_add_members_validity(body, mapper)
        if(response["statusCode"]==400):
            return  response
        if 'members' in body['add'] and 'lcms' in body["add"]['members'] and len(body["add"]["members"]["lcms"]):
            add_db_item = create_add_lcm_db_item(body["add"]["members"]["lcms"], groupName)
            db_item[GROUP_LCM_TABLE] = add_db_item
        if "description" in body["add"]:
            db_item[GROUP_TABLE]= [{
                "PutRequest":{
                    "Item": {
                        "groupName": {
                            "S":groupName
                        },
                        "description": {
                            "S": body["add"]["description"]
                        }
                    }
                }
            }]
    if("remove" in body):
        # response = check_members_exist(body["remove"], groupName)
        # if(response["statusCode"]==400):
        #     return  build_response(400,{"message": "unable to find lcms lamps", "found": response["extra"]})
        if 'members' in body['remove'] and 'lcms' in body["remove"]['members'] and len(body["remove"]["members"]["lcms"]):
            remove_db_item = create_remove_lcm_db_item(body["remove"]["members"]["lcms"], groupName)
            if GROUP_LCM_TABLE in db_item:
                for item in remove_db_item:
                    db_item[GROUP_LCM_TABLE].append(item)
            else:
                db_item[GROUP_LCM_TABLE] = remove_db_item
        if "description" in body["remove"]:
            db_item[GROUP_TABLE]= [{
                "PutRequest":{
                    "Item": {
                        "groupName": {
                            "S":groupName
                        }
                    }
                }
            }]
    dynamodb.batch_write_item(RequestItems= db_item)
    post_lcms = get_group_lcm(groupName)
    inform_hubs(body, groupName, pre_lcms, post_lcms)
    return build_response(200,"Group Updated")

        



def parse_request_body(event: dict):
    """Build and return response according to status code and message
    
    Parameters
    ----------
    event : dict
        details related to html request
        
    body:
        body of the html request

    Returns
    -------
    dict
        response of parsing
    """
    body = {}
    print(event)
    print(type(event['body']))

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)
        
    print(f"body: {event['body']}")
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")

    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    response = build_response(200,{"message":"success"})
    response["body"] = body
    return response

def initialize_mapper_and_schema():
    """ Initialize the request_schema object and mapper object"""
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
    return [request_schema, mapper]

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

def get_group(groupName):
    query = {
        "TableName": GROUP_TABLE,
        "KeyConditionExpression": "groupName = :gn",
        "ExpressionAttributeValues": {":gn": {'S': groupName}}
    }
    result = dynamodb.query(**query)
    if(len(result['Items'])>0):
        return {"statusCode": 200, "group":result['Items']}
    return {"statusCode": 400}

def check_group_exists(groupName):
    query = {
        "TableName": GROUP_TABLE,
        "KeyConditionExpression": "groupName = :gn",
        "ExpressionAttributeValues": {":gn": {'S': groupName}}
    }
    result = dynamodb.query(**query)
    if(len(result['Items'])>0):
        return True
    return False

def get_lcm_list(lcms):
    query = prepare_lcm_query(lcms)
    print(query)
    result = dynamodb.scan(**query)
    return result['Items'] 

def prepare_lcm_query(lcms):
    query = {"TableName": LCM_TABLE}
    scanfilter = {'ip': {
        'AttributeValueList': [],
        'ComparisonOperator': 'IN'
    }}
    for lcm in lcms:
        scanfilter['ip']['AttributeValueList'].append({'S': lcm})
    query['ScanFilter'] = scanfilter
    return query

def check_lcm_validity(lcms):
    lcm_list = get_lcm_list(lcms)
    if(len(lcms) != len(lcm_list)):
        extra = lcms
        print(extra)
        for lcm in lcm_list:
            print("popping: ",lcm["ip"]["S"])
            extra.remove(lcm["ip"]["S"])
        return {"statusCode": 400, "found": extra}
    return {"statusCode": 200, "lcms": lcm_list}

def get_group_list(groups):
    query = prepare_group_query(groups)
    print(query)
    result = dynamodb.scan(**query)
    return result['Items']

def prepare_group_query(groups):
    query = {"TableName": GROUP_TABLE}
    scanfilter = {'groupName': {
        'AttributeValueList': [],
        'ComparisonOperator': 'IN'
    }}
    for group in groups:
        scanfilter['groupName']['AttributeValueList'].append({'S': group})
    query['ScanFilter'] = scanfilter
    return query

def check_groups_validity(groups):
    group_list = get_group_list(groups)
    print("number of groups in db: ",len(group_list))
    if(len(groups) != len(group_list)):
        extra = groups
        for group in group_list:
            extra.remove(group["groupName"]["S"])
        return {"statusCode": 400, "found": extra}
    return {"statusCode": 200, "groups": group_list}

def check_add_members_validity(body, mapper):
    extras = {}
    groups = []
    lcms = []

    # if not (check_group_exists(body[mapper["groupName"]["request"]])):
    #     return build_response(400,{"message": f"{mapper['groupName']['request']} doesn't exist", "found": body[mapper["groupName"]["request"]]})

    if "members" in body["add"]:
        members = body["add"]["members"]
        if ("groups" in members and len(members[mapper["members"]["map"]["groups"]["request"]])>0):
            res = check_groups_validity(members[mapper["members"]["map"]["groups"]["request"]])
            if(res["statusCode"]==400):
                extras["group"] = res["found"]
            else:
                groups = res["groups"]
        if ("lcms" in members and len(members[mapper["members"]["map"]["lcms"]["request"]])>0):
            res = check_lcm_validity(members[mapper["members"]["map"]["lcms"]["request"]])
            if(res["statusCode"]==400):
                extras["lcm"] = res["found"]
            else:
                lcms = res["lcms"]
    if(len(extras)>0):
        return build_response(400,{"message": "invalid values found", "found": extras})
    res = {}
    if len(groups)>0:
        res["groups"] = groups
    if len(lcms)>0:
        res["lcms"] = lcms
    return {"statusCode":200, "body": res}

def create_add_lcm_db_item(lcms, groupName):
    items = []
    for lcm in lcms:
        items.append({
            "PutRequest": {
                "Item": {
                    "groupName": {
                        "S": groupName
                    },
                    "ip": {
                        "S": lcm
                    }
                }
            }
        })
    return items

def create_remove_lcm_db_item(lcms, groupName):
    items = []
    for lcm in lcms:
        items.append({
            "DeleteRequest": {
                "Key": {
                    "groupName": {
                        "S": groupName
                    },
                    "ip": {
                        "S": lcm
                    }
                }
            }
        })
    return items

def prepare_group_lcm_query(groups):
    query = {"TableName": GROUP_LCM_TABLE}
    scanfilter = {'groupName': {
        'AttributeValueList': [],
        'ComparisonOperator': 'IN'
    }}
    for group in groups:
        scanfilter['groupName']['AttributeValueList'].append({'S': group})
    query['ScanFilter'] = scanfilter
    return query

def get_group_lcm(groupName):
    query = prepare_group_lcm_query([groupName])
    print(query)
    result = dynamodb.scan(**query)
    lcms = []
    if 'Items' in result and len(result['Items'])>0:
        print(result['Items'])
        for item in result['Items']:
            lcms.append(item['ip']['S'])
    lcms.sort()
    return lcms

def check_members_exist(remove, groupName):
    if "members" in remove and "lcms" in remove["members"] and len(remove["members"]["lcms"])>0:
        lcms = get_group_lcm(groupName)
        print("check_members_exist: lcms: ", lcms)
        rm_lcms = remove["members"]["lcms"]
        rm_lcms.sort()
        print("check_members_exist: rm_lcms: ", rm_lcms)
        l1  = len(lcms)
        l2 = len(rm_lcms)
        i =0
        j = 0
        extra = []
        while(i<l1 or j<l2):
            if(i>=l1):
                extra.append(rm_lcms[j])
                j+=1
                continue
            if (j>=l2):
                break
            if(rm_lcms[j]<lcms[i]):
                extra.append(rm_lcms[j])
                j+=1
                continue
            if(lcms[i]<rm_lcms[j]):
                i+=1
                continue
            if(lcms[i]==rm_lcms[j]):
                i+=1
                j+=1
                continue
        if len(extra)>0:
            return {"statusCode":400, "extra": extra}
    return {"statusCode":200}


def mix_list(l1, l2):
    l3 = set()
    for a in l1:
        l3.add(a)
    for a in l2:
        l3.add(a)
    return list(l3)

def make_affected_hub_list(body, lcms):
    hubs = set()
    
    if "add" in body and 'members' in body['add'] and 'lcms' in body["add"]['members'] and len(body["add"]["members"]["lcms"]):
        for ad_lcm in body["add"]["members"]["lcms"]:
            hubs.add(lcms[ad_lcm])
    if "remove" in body and 'members' in body['remove'] and 'lcms' in body["remove"]['members'] and len(body["remove"]["members"]["lcms"]):
        for rm_lcm in body["remove"]["members"]["lcms"]:
            hubs.add(lcms[rm_lcm])
    return list(hubs)

def prepare_lcm_hub_list(lcms):
    lh = {}
    for lcm in lcms:
        lh[lcm['ip']['S']] = lcm['hubid']['S']
    return lh


def prepare_updated_mqtt_msg(groupName, hubs, lh, post_lcms):
    hubmap = {}
    for hub in hubs:
        hubmap[hub] = {
            "lamps": [],
            "groups": [ "subgroup1"],
            "name": groupName
        }
    for lcm in post_lcms:
        hubmap[lh[lcm]]["lamps"].append(lcm)
    return hubmap


def inform_hubs(body, groupName, pre_lcms, post_lcms):
    print("inform_hubs: pre_lcms: ", pre_lcms)
    print("inform_hubs: post_lcms: ", post_lcms)
    total_lcms = mix_list(pre_lcms, post_lcms)
    print("inform_hubs: total_lcms: ", total_lcms)
    if(len(total_lcms)==0):
        return
        
    all_lcms = get_lcm_list(total_lcms)
    lh = prepare_lcm_hub_list(all_lcms)
    print("inform_hubs: lh: ", lh)
    affected_hubs = make_affected_hub_list(body, lh)
    hubs = prepare_updated_mqtt_msg(groupName, affected_hubs, lh, post_lcms)
    print(hubs)
    for hub in hubs:
        mt = MQTT_TOPIC.replace('{hubid}',hub)
        iot_data.publish(
        topic= mt,
        qos=QOS,
        payload=json.dumps(hubs[hub]))