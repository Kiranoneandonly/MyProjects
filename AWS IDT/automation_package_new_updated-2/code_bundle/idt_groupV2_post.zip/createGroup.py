import json
import boto3
import time
from validateBody import validate_body

dynamodb = boto3.client('dynamodb')
iot_data = boto3.client('iot-data')

request_schema = {}
mapper = {}

GROUP_TABLE = "groupV2"
LCM_TABLE = "LCM"
GROUP_LCM_TABLE = "GroupLcm"
GROUP_GROUP_TABLE = "GroupGroup"

QOS = 0
MQTT_TOPIC = "idt/hub/{hubid}/group-update"

def create_group(event, context):
    """Commission a new lamp
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """

    response = parse_request_body(event)
    if response["statusCode"] == 400:
        return response
    request_schema, mapper = initialize_mapper_and_schema()
    print("request_schema: ", request_schema)
    body = response["body"]
    response = validate_body(body, request_schema)
    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)

    response = check_members_validity(body, mapper)
    if(response["statusCode"]==400):
        return  response

    save_group(body)
    hubs = prepare_mqtt_list(body, response['body']['lcms'])
    inform_hubs(hubs, body[mapper["groupName"]["request"]])
    return build_response(200,{"message": "Group Created"})




def parse_request_body(event: dict):
    """Build and return response according to status code and message
    
    Parameters
    ----------
    event : dict
        details related to html request
        
    body:
        body of the html request

    Returns
    -------
    dict
        response of parsing
    """
    body = {}
    print(event)
    print(type(event['body']))

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)
        
    print(f"body: {event['body']}")
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")

    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    response = build_response(200,{"message":"success"})
    response["body"] = body
    return response


def initialize_mapper_and_schema():
    """ Initialize the request_schema object and mapper object"""
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
    return [request_schema, mapper]

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

def check_members_validity(body, mapper):
    extras = {}
    groups = []
    lcms = []

    if(check_group_exists(body[mapper["groupName"]["request"]])):
        return build_response(400,{"message": f"{mapper['groupName']['request']} value already exist", "found": body[mapper["groupName"]["request"]]})

    if "members" in body:
        members = body[mapper["members"]["request"]]
        if ("groups" in members and len(members[mapper["members"]["map"]["groups"]["request"]])>0):
            res = check_groups_validity(members[mapper["members"]["map"]["groups"]["request"]])
            print(res)
            if(res["statusCode"]==400):
                extras["group"] = res["found"]
            else:
                groups = res["groups"]
        if ("lcms" in members and len(members[mapper["members"]["map"]["lcms"]["request"]])>0):
            res = check_lcm_validity(members[mapper["members"]["map"]["lcms"]["request"]])
            if(res["statusCode"]==400):
                extras["lcm"] = res["found"]
            else:
                lcms = res["lcms"]
    if(len(extras)>0):
        return build_response(400,{"message": "invalid values found", "found": extras})
    res = {}
    if len(groups)>0:
        res["groups"] = groups
    if len(lcms)>0:
        res["lcms"] = lcms
    return {"statusCode":200, "body": res}


def prepare_lcm_query(lcms):
    query = {"TableName": LCM_TABLE}
    scanfilter = {'ip': {
        'AttributeValueList': [],
        'ComparisonOperator': 'IN'
    }}
    for lcm in lcms:
        scanfilter['ip']['AttributeValueList'].append({'S': lcm})
    query['ScanFilter'] = scanfilter
    return query

def get_lcm_list(lcms):
    query = prepare_lcm_query(lcms)
    print(query)
    result = dynamodb.scan(**query)
    return result['Items']

def check_lcm_validity(lcms):
    lcm_list = get_lcm_list(lcms)
    if(len(lcms) != len(lcm_list)):
        extra = lcms
        print(extra)
        for lcm in lcm_list:
            print("popping: ",lcm["ip"]["S"])
            extra.remove(lcm["ip"]["S"])
        return {"statusCode": 400, "found": extra}
    return {"statusCode": 200, "lcms": lcm_list}

def prepare_group_query(groups):
    query = {"TableName": GROUP_TABLE}
    scanfilter = {'name': {
        'AttributeValueList': [],
        'ComparisonOperator': 'IN'
    }}
    for group in groups:
        scanfilter['name']['AttributeValueList'].append({'S': group})
    query['ScanFilter'] = scanfilter
    return query

def get_group_list(groups):
    query = prepare_group_query(groups)
    print(query)
    result = dynamodb.scan(**query)
    return result['Items']

def check_groups_validity(groups):
    group_list = get_group_list(groups)
    print("number of groups in db: ",len(group_list))
    if(len(groups) != len(group_list)):
        extra = groups
        for group in group_list:
            extra.remove(group["groupName"]["S"])
        return {"statusCode": 400, "found": extra}
    return {"statusCode": 200, "groups": group_list}

def check_group_exists(groupName):
    query = {
        "TableName": GROUP_TABLE,
        "KeyConditionExpression": "groupName = :gn",
        "ExpressionAttributeValues": {":gn": {'S': groupName}}
    }
    result = dynamodb.query(**query)
    if(len(result['Items'])>0):
        return True
    return False

def save_group(body):
    print(body["name"])
    groupName = body["name"]
    db_item = {}
    db_item["groupName"] = {'S': groupName}
    if "description" in body:
        db_item["description"] = {'S': body["description"]}
    dynamodb.put_item(TableName = GROUP_TABLE, Item = db_item)
    if "members" in body:
        save_group_members(body)

def save_group_members(body):
    request_items = {}
    if "lcms" in body["members"]:
        request_items[GROUP_LCM_TABLE] = prepare_lcm_batch_write(body)
        dynamodb.batch_write_item(RequestItems= request_items)
    if "groups" in body["members"]:
        request_items[GROUP_GROUP_TABLE] = prepare_group_batch_write(body)
        dynamodb.batch_write_item(RequestItems= request_items)

def prepare_lcm_batch_write(body):
    items = []
    groupName = body["name"]
    for lcm in body["members"]["lcms"]:
        items.append({
            'PutRequest': {
                'Item': {
                    "groupName": {
                        "S": groupName
                    },
                    "ip": {
                        "S": lcm
                    }
                }
            }
        })
    return items

def prepare_group_batch_write(body):
    items = []
    groupName = body["name"]
    for group in body["members"]["groups"]:
        items.append({
            'PutRequest': {
                'Item': {
                    "groupName": {
                        "S": groupName
                    },
                    "childGroupName": {
                        "S": group
                    }
                }
            }
        })
    return items

def prepare_group_group_query(groups):
    query = {"TableName": GROUP_GROUP_TABLE}
    scanfilter = {'groupName': {
        'AttributeValueList': [],
        'ComparisonOperator': 'IN'
    }}
    for group in groups:
        scanfilter['groupName']['AttributeValueList'].append({'S': group})
    query['ScanFilter'] = scanfilter
    return query

def get_group_group_list(groups):
    query = prepare_group_group_query(groups)
    print(query)
    result = dynamodb.scan(**query)
    return result['Items']

def aggrigate_child_groups(groups):
    groups = set()
    children = get_group_group_list(groups)
    for child in children:
        set.add(child["childGroupName"]["S"])
    return groups


def prepare_group_list(groupList):
    childList = set()
    groupGroup = get_group_group_list(groupList)
    for i in groupList:
        childList.add(i)
    for g in groupGroup:
        childList.add(g)
    return childList

def prepare_mqtt_list(body, lcms):
    hubs = {}
    for lcm in lcms:
        if lcm["hubid"]["S"] in hubs:
            hubs[lcm["hubid"]["S"]]["lamps"].add(lcm["ip"]["S"])
        else:
            hubs[lcm["hubid"]["S"]] = {"lamps":set()}
            hubs[lcm["hubid"]["S"]]["lamps"].add(lcm["ip"]["S"])
    print(hubs)
    return hubs


def inform_hubs(hubs, groupName):
    print(groupName)
    for hub in hubs:
        mt = MQTT_TOPIC.replace("{hubid}",hub)
        iot_data.publish(
        topic= mt,
        qos=QOS,
        payload=json.dumps({
            "lamps": list(hubs[hub]["lamps"]),
            "name": groupName
        }))