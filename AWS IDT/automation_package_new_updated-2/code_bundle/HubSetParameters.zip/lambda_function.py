import json
import boto3

iot = boto3.client('iot')


def set_params(event, context):
    """updates the attribute of the hub
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    # hubs = iot.list_things()
    print(event)
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")
    body = json.loads(event["body"])
    hubid = event['pathParameters']['hubid']

    if "deviceMAC" in body:
        body.pop("deviceMAC")

    try:
        print(hubid)
        response = iot.update_thing(
            thingName=hubid,
            attributePayload={
                'attributes': body,
                'merge': True
            }
        )

        return {
            "statusCode": 200,
            "body": json.dumps('success')
        }
    except Exception:
        print(Exception)
        print(f"Resourse {hubid} not found")
        return {
            "statusCode": 404,
            "body": json.dumps(f"Resourse {hubid} not found")
        }
