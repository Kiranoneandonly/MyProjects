
import boto3
import json

from boto3.dynamodb.conditions import Key, Attr

from decimal import Decimal
import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return {'__Decimal__': str(obj)}
        # Let the base class default method raise the TypeError
        return json.JSONEncoder.default(self, obj)

def as_Decimal(dct):
    if '__Decimal__' in dct:
        return decimal.Decimal(dct['__Decimal__'])
    return dct
    
def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('day')
    response = table.scan()
    print(response["Items"])
    return  {
                'statusCode': 200,
                'body': json.dumps(response,  cls=DecimalEncoder),
                 "headers": {
                    "Access-Control-Allow-Origin" : "*",
                     "Accept" : "application/json"
                    }

            }