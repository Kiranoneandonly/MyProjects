import boto3
import json

def lambda_handler(event, context):
    # TODO implement
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('week')
    print(json.loads(event['body']))
    response = table.put_item(
        Item=json.loads(event['body']))
    return {
        'statusCode': 200,
        'body': json.dumps('post done !!'),
                         "headers": {
                    "Access-Control-Allow-Origin" : "*",
                     "Accept" : "application/json"
                    }
    }

