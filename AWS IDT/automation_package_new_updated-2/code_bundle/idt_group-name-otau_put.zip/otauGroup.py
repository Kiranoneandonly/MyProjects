import json
import boto3
from validateBody import validate_body

iot = boto3.client('iot-data')
dynamodb = boto3.client('dynamodb')

GROUP_TABLE = "groupV2"
DEFAULT_TRANSITION_TIME = 2
QOS = 0
LAMP_DIM_LEVEL_RANGE = [0,1000]
dim_mqtt_topic = "idt/group/{groupname}/update"
request_schema = {}
mapper = {}


def group_ota(event, context):
    """Forwards the update file link to the group for update
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)

    groupName = event['pathParameters']['name']
    
    print(type(event['body']))
    print(f"body: {event['body']}")

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)

    event["body"].replace("\n ","")
    
    body = {}
    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
        

    response = validate_body(body, request_schema)

    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)

    print("Checking group entry in db")

    db_result = dynamodb.scan(TableName=GROUP_TABLE,ScanFilter={
        'groupName': {
            'AttributeValueList': [
                {
                    'S': groupName
                }
            ],
            'ComparisonOperator': 'EQ'
        }
    })

    print("db result: ",db_result)

    group = db_result['Items']

    if group==None or len(group)==0:
        print("Unable to find any associated group sending 404 response")
        return build_response(404,f"Resourse: {groupName} not found")

    
    mt = dim_mqtt_topic.replace("{groupname}",groupName)
    message = {"transition-time": DEFAULT_TRANSITION_TIME}
    message = build_message(body, mapper)

    print("sending MQTT request")
    iot.publish(
        topic= mt,
        qos=QOS,
        payload=json.dumps(message))
    return build_response(200,{"message":"Success"})

def build_message(body: dict,mapper: dict) -> dict:
    """Build and return mqtt message according to mapper and body and fills in message provided
    
    Parameters
    ----------
    body: dict
        request body
        
    message: dict
        dict in which message has to be written

    mapper: dict
        maps body and message fields

    Returns
    -------
    dict
        mqt message payload
    """
    message = {}
    for key in mapper:
        if mapper[key]["request"] in body:
            message[mapper[key]["mqtt"]] = body[mapper[key]["request"]]
    return message

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }