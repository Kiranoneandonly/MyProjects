import json
import boto3

dynamodb = boto3.client('dynamodb')

TABLE_NAME = "group"

def get_group(event, context):
    """Return the list of lamps
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    print(event)

    groupName = event['pathParameters']['name']

    request = { 
                    "TableName": TABLE_NAME,
                    "Key": {
                        "groupName": {"S": groupName}
                    }
                }
    print(request)
    result = dynamodb.get_item(**request)

    print("db fetching result: ",result)
    if (not "Item" in result) or result["Item"] == None:
        return {
            'statusCode': 404,
            'body': json.dumps('Resourse not found'),
            "headers": {
                "Access-Control-Allow-Origin" : "*",
                "Accept" : "application/json"
            }
        }

    response = {"group": []}

    if 'Item' in result:
        response["group"].append(prepare_group_response(result['Item']))

    return {
        'statusCode': 200,
        'body': json.dumps(response),
        "headers": {
            "Access-Control-Allow-Origin" : "*",
            "Accept" : "application/json"
        }
    }


def prepare_group_response(group):
    response = {"name": group['groupName']['S']}
    if "description" in group:
        response["descripton"] = group['description']['S']
    if "lamps" in group or "groups" in group:
        response["members"] = {}
    if "lamps" in group:
        response["members"]["lcms"] = []
        for lcm in group["lamps"]["L"]:
            response["members"]["lcms"].append(lcm['M']['ip']['S'])
    if "groups" in group:
        response["members"]["groups"] = []
        for gr in group["groups"]["L"]:
            response["members"]["groups"].append(gr['S'])
    return response