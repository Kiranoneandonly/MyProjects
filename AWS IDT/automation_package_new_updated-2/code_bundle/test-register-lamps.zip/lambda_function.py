import json
import boto3
import time
import datetime
from validateBody import validate_body

dynamodb = boto3.client('dynamodb')

TABLE_NAME = "LCMMaster"

response_include = ["ip","key","mfd","batch","firmware"]

request_schema = {}
request_db_map = {}

def register(event, context):
    """Register a new lamp
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    
    print(event)
    print(type(event['body']))
    print(f"body: {event['body']}")
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")
    body = json.loads(event["body"])

    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        

    with open('mapper.json') as json_file:
        request_db_map = json.load(json_file)

    validation_result = validate_body(body, request_schema)

    print("validation response:",validation_result)

    if validation_result["statusCode"] == 0:
        # validation_result["statusCode"] = 400
        validation_result.pop('statusCode')
        return {"statusCode": 400,
                "body": json.dumps(validation_result)}
    
    tm = time.time()

    body["key"] = generatePrimaryKey()

    dt = datetime.datetime.fromtimestamp(tm)

    # mfd = dt.strftime("%d %b %Y")

    # print(mfd)

    body["mfd"] = {
        "year": dt.year,
        "month": dt.month,
        "day": dt.day,
        "weekday": dt.isoweekday(),
        "hour": dt.hour,
        "minute": dt.minute,
        "second": dt.second,
        "timestamp": tm
    }

    db_entry = populate_dict_for_db_entry(body,request_db_map)

    print("Entering in db: ",db_entry)

    db_reponse = dynamodb.put_item(TableName = TABLE_NAME, Item= db_entry)

    print("database response: ",db_reponse)
    
    response = generate_response(body,response_include)

    response["mfd"] = tm 
    
    print("response: ",response)

    return {
        'statusCode': 200,
        'body': json.dumps(response),
        "headers": {
             "Access-Control-Allow-Origin" : "*",
             "Accept" : "application/json"
        }
    }



def populate_dict_for_response(items: dict, db_map: dict) -> dict:
    """Return an dictionary populated with items according to the scehma specified
    
    Parameters
    ----------
    items : dict
        dict whose data needs to be duplicated

    db_map : dict
        schema in which way data will transformed, request is the target data while db is the way data is mentioned.

    Returns
    -------
    dict
        dict of items duplicated from items
    """
    itnr = {}
    for item in items:
        for map_element in db_map:
            if db_map[map_element]["db"] in item:
                for key in item[db_map[map_element]["db"]]:
                    itnr[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    if key=='S':
                        itnr[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key=='N':
                        itnr[db_map[map_element]["request"]] = float(item[db_map[map_element]["db"]][key])
                    elif key=='M':
                        itnr[db_map[map_element]["request"]] = populate_dict_for_response(item[db_map[map_element]["db"]][key],db_map[map_element]["map"])
                    elif key == 'SS':
                        itnr[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key == 'NS':
                        number_list = []
                        for ele in item[db_map[map_element]["db"]][key]:
                            number_list.append(float(ele))
                        itnr[db_map[map_element]["request"]] = number_list
    return itnr

def populate_dict_for_db_entry(items: dict, db_map: dict) -> dict:
    """Return an dictionary populated with items according to the scehma specified and can be used to enter in db
    
    Parameters
    ----------
    items : dict
        dict whose data needs to be duplicated

    db_map : dict
        schema in which way data will transformed, db is the target data while request is the way data is mentioned.

    Returns
    -------
    dict
        dict of items duplicated from items
    """
    itnr = {}
    for item in items:
        for map_element in db_map:
            if db_map[map_element]["request"] == item:
                key = db_map[map_element]["type"]
                if key == "M":
                    itnr[db_map[map_element]["db"]] = { key: populate_dict_for_db_entry(items[item], db_map[map_element]["map"])}
                elif key== "S": 
                    itnr[db_map[map_element]["db"]] = { key: items[item]}
                elif key== "N":
                    itnr[db_map[map_element]["db"]] = { key: str(items[item])}
    return itnr


def generatePrimaryKey() -> str:
    """Return primary key
    
    Returns
    -------
    str
        Generated Primary Key
    """
    tm = time.time()
    tm = tm*10000
    tm = int(tm)

    tm = base36encode(tm)
    

    print("Generated Primary Key: ", tm)

    while len(tm) <10:
        tm = "0"+tm
    tm = "LT-"+tm
    return tm


def base36encode(integer) -> str:
    """Return a base 36 number corrosponding to base 10 integer provided
    
    Parameters
    ----------
    integer : int
        base 10 integer for which base 36 has to be provided 

    Returns
    -------
    str
        generated base36 number 
    """
    chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    sign = '-' if integer < 0 else ''
    integer = abs(integer)
    result = ''
    while integer > 0:
        integer, remainder = divmod(integer, 36)
        result = chars[remainder]+result
    return sign+result


def generate_response(body: dict,response: list):
    """Create and return part of body which is mentioned in list
    
    Parameters
    ----------
    body : dict
        dict whose data needs to be duplicated

    response : list
        list of items to be included

    Returns
    -------
    dict
        dict of items duplicated from body
    """
    item = {}
    for res in response:
        if res in body:
            item[res] = body[res]

    return item