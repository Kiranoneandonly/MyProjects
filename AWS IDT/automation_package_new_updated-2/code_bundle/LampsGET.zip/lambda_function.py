import json
import boto3

dynamodb = boto3.client('dynamodb')

TABLE_NAME = 'LCM'

db_map = {}

def list_lamp(event, context):

    print(event)
    
    with open('mapper.json') as json_file:
        db_map = json.load(json_file)

    result = dynamodb.scan(TableName=TABLE_NAME)

    print("db result:",result)

    lamp = result['Items']

    if lamp==None or len(lamp)==0:
        return {
            'statusCode': 404,
            'body': json.dumps(f"Resourse not found")
        }
    
    lamps = json.dumps(populate_list(lamp, db_map))
    print("lamps: ",lamps)
    
    
    return {
            'statusCode': 200,
            'body': lamps,
            "headers": {
             "Access-Control-Allow-Origin" : "*",
             "Accept" : "application/json"
            }
        }


def populate_list(items: dict, db_map: dict):
    Arr=[]

    for item in items:
        element = {}
        for map_element in db_map:
            if db_map[map_element]["db"] in item:
                for key in item[db_map[map_element]["db"]]:
                    element[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    if key=='S':
                        element[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key=='N':
                        element[db_map[map_element]["request"]] = float(item[db_map[map_element]["db"]][key])
                    elif key=='M':
                        element[db_map[map_element]["request"]] = populate_dict(item[db_map[map_element]["db"]][key],db_map[map_element]["map"])
                    elif key == 'SS':
                        element[db_map[map_element]["request"]] = item[db_map[map_element]["db"]][key]
                    elif key == 'NS':
                        number_list = []
                        for ele in item[db_map[map_element]["db"]][key]:
                            number_list.append(float(ele))
                        element[db_map[map_element]["request"]] = number_list
        Arr.append(element)
    return Arr

def populate_dict(items: dict, db_map: dict) -> dict:
    itnr = {}
    for map_element in db_map:
        if db_map[map_element]["db"] in items:
            for key in items[db_map[map_element]["db"]].keys():
                itnr[db_map[map_element]["request"]] = items[db_map[map_element]["db"]][key]
                if key=='S':
                    itnr[db_map[map_element]["request"]] = items[db_map[map_element]["db"]][key]
                elif key=='N':
                    itnr[db_map[map_element]["request"]] = float(items[db_map[map_element]["db"]][key])
                elif key=='M':
                    itnr[db_map[map_element]["request"]] = populate_dict(items[db_map[map_element]["db"]][key],db_map[map_element]["map"])
                elif key == 'SS':
                    itnr[db_map[map_element]["request"]] = items[db_map[map_element]["db"]][key]
                elif key == 'NS':
                    number_list = []
                    for ele in items[db_map[map_element]["db"]][key]:
                        number_list.append(float(ele))
                    itnr[db_map[map_element]["request"]] = number_list
    return itnr