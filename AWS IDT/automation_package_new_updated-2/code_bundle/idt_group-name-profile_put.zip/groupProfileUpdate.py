import json
import boto3
import time
from validateBody import validate_body

dynamodb = boto3.client('dynamodb')
iot_data = boto3.client('iot-data')

request_schema = {}
mapper = {}

GROUP_TABLE = "groupV2"
WEEK_TABLE = "week"
GROUP_PROFILE_TABLE = "profileGroup"

def update_group_prfile(event, context):
    """Commission a new lamp
    
    Parameters
    ----------
    event : dict
        details related to html request

    context:
        object provides methods and properties that provide information about the invocation, function, and execution environment
        for more details visit:
        https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    -------
    json
        a response in a form of json
    """
    groupName = event['pathParameters']['name']
    
    response = parse_request_body(event)
    if response["statusCode"] == 400:
        return response
    request_schema, mapper = initialize_mapper_and_schema()
    print("request_schema: ", request_schema)
    body = response["body"]
    body['name'] = groupName
    response = validate_body(body, request_schema)
    print("validation response:",response)

    if response["statusCode"] == 0:
        response["message"] = "Bad Request! Please check other fields for more details"
        response["statusCode"] = 400
        return build_response(response.pop("statusCode"),response)
    
    groupExists = get_group(groupName)
    if(groupExists["statusCode"]==400):
        return build_response(400, {
            "message": "Requested group does not exist",
            "found": groupName
            })
    if(body["action"]=="update"):
        profileExist = get_profile(body['profile'])
        if(profileExist["statusCode"]==400):
            return build_response(400, {
                "message": "Requested profile does not exist",
                "found": groupName
                })
        if(body["profile"]==""):
            return build_response(400, {
                "message": "Requested profile does not exist",
                "found": groupName
                })
        save_to_db(groupName, body['profile'])
    if(body["action"]=="remove"):
        remove_entry_from_db(groupName)
    
    return build_response(200, "Success")
    
    
    


def parse_request_body(event: dict):
    """Build and return response according to status code and message
    
    Parameters
    ----------
    event : dict
        details related to html request
        
    body:
        body of the html request

    Returns
    -------
    dict
        response of parsing
    """
    body = {}
    print(event)
    print(type(event['body']))

    if(event['body']==None or event['body']== ""):
        response_body = {"message": "Request Body Missing"}
        return build_response(400, response_body)
        
    print(f"body: {event['body']}")
    event["body"] = event["body"].replace("\n ","")
    event["body"] = event["body"].replace("\t","")

    try:
        body = json.loads(event["body"])
    except Exception:
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    if(type(body)!=dict):
        return build_response(400, {"message": "Error parsing body, Please check the request body."})
    
    response = build_response(200,{"message":"success"})
    response["body"] = body
    return response

def initialize_mapper_and_schema():
    """ Initialize the request_schema object and mapper object"""
    with open('request_schema.json') as json_file:
        request_schema = json.load(json_file)
        
    with open('mapper.json') as json_file:
        mapper = json.load(json_file)
    return [request_schema, mapper]

def build_response(statusCode: int,response_body: dict) -> dict:
    """Build and return response according to status code and message
    
    Parameters
    ----------
    statusCode: int
        status code for response. eg. 404
        
    body:
        response message for genreate eg. Resourse Not Found

    Returns
    -------
    dict
        response
    """
    return  {
                'statusCode': statusCode,
                'body': json.dumps(response_body),
                "headers": {
                    "Access-Control-Allow-Origin" : "*",
                    "Accept" : "application/json"
                }
            }

def get_group(groupName):
    """return profile dict from database if present
        if success statusCode is 200 on failure statusCode is 400
        with sattusCode: 200, prfile is also sent  
    Parameters
    ----------
    profile: str
        name of the profile

    Returns
    -------
    dict
        a dictionary with statusCode and group
    """
    query = {
        "TableName": GROUP_TABLE,
        "KeyConditionExpression": "groupName = :gn",
        "ExpressionAttributeValues": {":gn": {'S': groupName}}
    }
    result = dynamodb.query(**query)
    if(len(result['Items'])>0):
        return {"statusCode": 200, "group":result['Items']}
    return {"statusCode": 400}

def get_profile(profile):
    """return profile dict from database if present
        if success statusCode is 200 on failure statusCode is 400
        with sattusCode: 200, prfile is also sent  
    Parameters
    ----------
    profile: str
        name of the profile

    Returns
    -------
    dict
        a dictionary with statusCode and profile
    """
    query = {
        "TableName": WEEK_TABLE,
        "KeyConditionExpression": "id = :pn",
        "ExpressionAttributeValues": {":pn": {'S': profile}}
    }
    result = dynamodb.query(**query)
    if(len(result['Items'])>0):
        return {"statusCode": 200, "profile":result['Items']}
    return {"statusCode": 400}

def save_to_db(groupName, profile):
    """Save changes to database
    
    Parameters
    ----------
    groupName: str
        name of the group

    profile: str
        name of the profile
    """
    dynamodb.put_item(TableName = GROUP_PROFILE_TABLE,  
        Item={
            "groupName": {'S': groupName},
            "profile": {'S': profile}
        }
    )

def remove_entry_from_db(groupName):
    """Removes entry of a group from db
    
    Parameters
    ----------
    groupName: str
        name of the group
    """
    dynamodb.delete_item(TableName = GROUP_PROFILE_TABLE,  
        Key={
            "groupName": {'S': groupName}
        }
    )